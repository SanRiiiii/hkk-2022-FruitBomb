﻿#include "Printpoint.h"
#include"SetWindows.h"
#include<iostream>
using namespace std;
Printpoint::Printpoint(const int x, const int y) :
	x(x), y(y)
{
}
void Printpoint::Printrectangle()
{
	SetPosition(x, y);
	cout << "■";
}
void Printpoint::Printcircle()
{
	SetPosition(x, y);
	cout << "◆";
}
void Printpoint::Printstar()
{
	SetPosition(x, y);
	cout << "★";
}
void Printpoint::Printbomb()
{
	SetPosition(x, y);
	cout << "⊙";
}
void Printpoint::Printblock()
{
	SetPosition(x, y);
	cout << "〓";
}
void Printpoint::PrintSuperBomb()
{
	SetPosition(x, y);
	cout << "◎";
}
void Printpoint::Printtree()
{
	SetPosition(x, y);
	cout << "Ж";
}
void Printpoint::PrintPlayer1()
{
	SetPosition(x, y);
	cout << "PLAYER_1";

}
void Printpoint::PrintPlayer2()
{
	SetPosition(x, y);
	cout << "PLAYER_2";

}
void Printpoint::PrintStealthBomb()
{
	SetPosition(x, y);
	cout << "¤";
}
void Printpoint::PrintPoison()
{
	SetPosition(x, y);
	cout << "▽";
}
void Printpoint::PrintData(int i)
{
	SetPosition(x, y);
	cout << ":  " << i;

}
void Printpoint::Clear()
{
	SetPosition(x, y);
	cout << "  ";
}
void Printpoint::Changeposition(const int x, const int y)
{
	this->x = x;
	this->y = y;
}
bool Printpoint::operator==(const Printpoint& point)
{
	return (point.x == this->x) && (point.y == this->y);
}
int Printpoint::GetX()
{
	return this->x;
}
int Printpoint::GetY()
{
	return this->y;
}
