#include "map.h"
#include"SetWindows.h"
#include<iostream>
#include<Windows.h>
#include<ctime>
#include<cstdlib>
using namespace std;
extern int Attr[22][22] = { 0 };
void Map::PushWall()
{
	int i, j;
	for (i = 10; i <= 56; i += 46)//����˫��ѭ����initmapѹ����� 
		for (j = 5; j <= 28; j++)
			Wall.emplace_back(Printpoint(i, j));

	for (i = 12; i <= 54; i++)
		for (j = 5; j <= 28; j += 23)
			Wall.emplace_back(Printpoint(i, j));
}

void Map::printWall()
{
	for (auto& Printpoint : Wall)
	{
		SetColor(LIGHTYELLOW, DARKBLUE);
		Printpoint.Printrectangle();
	}
}

void Map::PushBorder()
{
	for (int i = 28; i <= 36; i++)
	{
		Border.emplace_back(Printpoint(i * 2, 5));
		Border.emplace_back(Printpoint(i * 2, 28));
		Border.emplace_back(Printpoint(i * 2, 12));
		Border.emplace_back(Printpoint(i * 2, 19));
	}
	for (int i = 5; i <= 28; i++)
		Border.emplace_back(Printpoint(36 * 2, i));


}

void Map::PrintBorder()
{
	for (auto& Printpoint : Border)
	{
		if (Printpoint.GetY() == 12 && (Printpoint.GetX() >= 29 * 2 && Printpoint.GetX() <= 35 * 2) || Printpoint.GetY() == 19 && (Printpoint.GetX() >= 29 * 2 && Printpoint.GetX() <= 35 * 2))
		{
			SetColor(LIGHTYELLOW, DARKBLUE);
			Printpoint.Printblock();
		}
		else
		{
			SetColor(LIGHTYELLOW, DARKBLUE);
			Printpoint.Printrectangle();
		}
	}
}


void Map::PushMap1_cherry1()
{
	map1_cherry1.emplace_back(Printpoint(17 * 2, 8));
	map1_cherry1.emplace_back(Printpoint(18 * 2, 9));
	map1_cherry1.emplace_back(Printpoint(19 * 2, 10));
	map1_cherry1.emplace_back(Printpoint(20 * 2, 10));
	map1_cherry1.emplace_back(Printpoint(21 * 2, 11));
	map1_cherry1.emplace_back(Printpoint(22 * 2, 12));
	map1_cherry1.emplace_back(Printpoint(23 * 2, 13));
	map1_cherry1.emplace_back(Printpoint(16 * 2, 14));
	map1_cherry1.emplace_back(Printpoint(17 * 2, 13));
	map1_cherry1.emplace_back(Printpoint(18 * 2, 12));
	map1_cherry1.emplace_back(Printpoint(19 * 2, 11));
	map1_cherry1.emplace_back(Printpoint(20 * 2, 11));
	map1_cherry1.emplace_back(Printpoint(20 * 2, 12));
	map1_cherry1.emplace_back(Printpoint(19 * 2, 13));
	map1_cherry1.emplace_back(Printpoint(19 * 2, 14));
	map1_cherry1.emplace_back(Printpoint(19 * 2, 15));

}
void Map::PushMap1_cherry2()
{
	map1_cherry2.emplace_back(Printpoint(12 * 2, 12));
	map1_cherry2.emplace_back(Printpoint(11 * 2, 12));
	map1_cherry2.emplace_back(Printpoint(13 * 2, 12));
	for (int i = 10; i <= 15; i++)
	{
		map1_cherry2.emplace_back(Printpoint(i * 2, 13));
	}
	for (int i = 9; i <= 15; i++)
	{
		map1_cherry2.emplace_back(Printpoint(i * 2, 14));
	}
	for (int i = 8; i <= 15; i++)
	{
		map1_cherry2.emplace_back(Printpoint(i * 2, 15));
	}
	for (int i = 8; i <= 16; i++)
	{
		map1_cherry2.emplace_back(Printpoint(i * 2, 16));
	}
	for (int i = 8; i <= 16; i++)
	{
		map1_cherry2.emplace_back(Printpoint(i * 2, 17));
	}
	for (int i = 8; i <= 15; i++)
	{
		map1_cherry2.emplace_back(Printpoint(i * 2, 18));
	}
	for (int i = 9; i <= 15; i++)
	{
		map1_cherry2.emplace_back(Printpoint(i * 2, 19));
	}
	for (int i = 10; i <= 15; i++)
	{
		map1_cherry2.emplace_back(Printpoint(i * 2, 20));
	}
	for (int i = 11; i <= 13; i++)
	{
		map1_cherry2.emplace_back(Printpoint(i * 2, 21));
	}
}
void Map::PushMap1_cherry3()
{
	for (int i = 20; i <= 21; i++)
	{
		map1_cherry3.emplace_back(Printpoint(i * 2, 15));
	}
	for (int i = 20; i <= 21; i++)
	{
		map1_cherry3.emplace_back(Printpoint(i * 2, 15));
	}
	for (int i = 18; i <= 22; i++)
	{
		map1_cherry3.emplace_back(Printpoint(i * 2, 16));
	}
	for (int i = 17; i <= 23; i++)
	{
		map1_cherry3.emplace_back(Printpoint(i * 2, 17));
	}
	for (int i = 16; i <= 24; i++)
	{
		map1_cherry3.emplace_back(Printpoint(i * 2, 18));
	}
	for (int i = 16; i <= 24; i++)
	{
		map1_cherry3.emplace_back(Printpoint(i * 2, 19));
	}
	for (int i = 17; i <= 23; i++)
	{
		map1_cherry3.emplace_back(Printpoint(i * 2, 20));
	}
	for (int i = 18; i <= 22; i++)
	{
		map1_cherry3.emplace_back(Printpoint(i * 2, 21));
	}
	for (int i = 19; i <= 21; i++)
	{
		map1_cherry3.emplace_back(Printpoint(i * 2, 22));
	}
}

void Map::printMap1_cherry()
{
	for (auto& Printpoint : map1_cherry1)
	{
		SetColor(DARKGREEN, WHITE);
		Printpoint.Printrectangle();
	}
	for (auto& Printpoint : map1_cherry2)
	{
		SetColor(DARKRED, WHITE);
		Printpoint.Printrectangle();
	}
	for (auto& Printpoint : map1_cherry3)
	{
		SetColor(LIGHTRED, WHITE);
		Printpoint.Printrectangle();
	}

}

void Map::PushBlock()
{
	for (int i = 5; i < 14; i++)
	{
		Block.emplace_back(Printpoint((i + 6) * 2, 7));
		Attr[i][1] = 7;
	}
	for (int i = 15; i < 19; i++)
	{
		Block.emplace_back(Printpoint((i + 6) * 2, 7));
		Attr[i][7] = 7;
	}
	for (int i = 6; i < 13; i++)
	{
		Block.emplace_back(Printpoint(52, i));
		Attr[20][i - 6] = 7;
	}
	for (int i = 1; i < 9; i++)
	{
		Block.emplace_back(Printpoint((i + 6) * 2, 9));
		Attr[i][3] = 7;
	}
	for (int i = 7; i < 12; i++)
	{
		Block.emplace_back(Printpoint(48, i));
		Attr[18][i - 6] = 7;
	}
	for (int i = 11; i < 19; i++)
	{
		Block.emplace_back(Printpoint(14, i));
		Attr[1][i - 6] = 7;
	}
	Block.emplace_back(Printpoint(28, 9));
	Attr[8][3] = 7;
	Block.emplace_back(Printpoint(54, 14));
	Attr[21][8] = 7;
	for (int i = 3; i < 5; i++)
	{
		Block.emplace_back(Printpoint((i + 6) * 2, 11));
		Attr[i][5] = 7;
		Block.emplace_back(Printpoint((i + 4) * 2, 20));
		Attr[i - 2][14] = 7;
		Block.emplace_back(Printpoint((i + 23) * 2, 22));
		Attr[i + 17][16] = 7;
		Block.emplace_back(Printpoint((i + 9) * 2, 26));
		Attr[i + 3][20] = 7;
	}
	for (int i = 1; i < 10; i++)
	{
		Block.emplace_back(Printpoint((i + 6) * 2, 22));
		Attr[i][16] = 7;
	}
	for (int i = 11; i < 18; i++)
	{
		Block.emplace_back(Printpoint((i + 6) * 2, 23));
		Attr[i][17] = 7;
	}
	for (int i = 1; i < 6; i++)
	{
		Block.emplace_back(Printpoint((i + 6) * 2, 24));
		Attr[i][18] = 7;
		Block.emplace_back(Printpoint((i + 18) * 2, 25));
		Attr[i + 12][19] = 7;
	}
	for (int i = 18; i < 21; i++)
	{
		Block.emplace_back(Printpoint(14, i + 6));
		Attr[1][i] = 7;
		Block.emplace_back(Printpoint(34, i + 7));
		Attr[11][i + 1] = 7;
	}
	for (int i = 20; i < 22; i++)
	{
		Block.emplace_back(Printpoint(20, i + 6));
		Attr[4][i] = 7;
		Block.emplace_back(Printpoint(26, i + 4));
		Attr[7][i - 2] = 7;
		Block.emplace_back(Printpoint(30, i + 2));
		Attr[9][i - 4] = 7;
		Block.emplace_back(Printpoint(46, i + 1));
		Attr[17][i - 5] = 7;
	}
	for (int i = 17; i < 21; i++)
	{
		Block.emplace_back(Printpoint((i + 6) * 2, 15));
		Attr[i][9] = 7;
	}
	for (int i = 9; i < 15; i++)
	{
		Block.emplace_back(Printpoint(52, i + 6));
		Attr[20][i] = 7;
	}


}

void Map::PrintBlock()
{
	for (auto& Printpoint : Block)
	{
		SetColor(DARKGREY, WHITE);
		Printpoint.Printrectangle();
	}
}

void Map::PushMap2_peach1()
{
	for (int i = 10; i < 12; i++)
	{
		map2_peach1.emplace_back(Printpoint((i + 6) * 2, 8));
	}
	for (int i = 9; i < 13; i++)
	{
		map2_peach1.emplace_back(Printpoint((i + 6) * 2, 9));
		map2_peach1.emplace_back(Printpoint((i + 6) * 2, 10));
	}
	for (int i = 7; i < 15; i++)
	{
		map2_peach1.emplace_back(Printpoint((i + 6) * 2, 11));
	}
	for (int i = 6; i < 16; i++)
	{
		map2_peach1.emplace_back(Printpoint((i + 6) * 2, 12));
		map2_peach1.emplace_back(Printpoint((i + 6) * 2, 13));
	}
	map2_peach1.emplace_back(Printpoint(22, 13));
	for (int i = 4; i < 17; i++)
	{
		map2_peach1.emplace_back(Printpoint((i + 6) * 2, 14));
		map2_peach1.emplace_back(Printpoint((i + 6) * 2, 15));
	}
	for (int i = 3; i < 18; i++)
	{
		map2_peach1.emplace_back(Printpoint((i + 6) * 2, 16));
		map2_peach1.emplace_back(Printpoint((i + 6) * 2, 17));
		map2_peach1.emplace_back(Printpoint((i + 6) * 2, 18));
	}
	for (int i = 5; i < 16; i++)
	{
		map2_peach1.emplace_back(Printpoint((i + 6) * 2, 19));
	}
	for (int i = 7; i < 16; i++)
	{
		map2_peach1.emplace_back(Printpoint((i + 6) * 2, 20));
	}


}
void Map::PushMap2_peach2()
{
	map2_peach2.emplace_back(Printpoint(20, 20));
	map2_peach2.emplace_back(Printpoint(22, 20));
	map2_peach2.emplace_back(Printpoint(44, 20));
	map2_peach2.emplace_back(Printpoint(46, 20));
	map2_peach2.emplace_back(Printpoint(48, 20));
	map2_peach2.emplace_back(Printpoint(36, 21));
	map2_peach2.emplace_back(Printpoint(38, 21));
	map2_peach2.emplace_back(Printpoint(40, 21));
}
void Map::printMap2_peach()
{
	for (auto& Printpoint : map2_peach1)
	{
		SetColor(LIGHTRED, WHITE);
		Printpoint.Printrectangle();
	}
	for (auto& Printpoint : map2_peach2)
	{
		SetColor(LIGHTGREEN, WHITE);
		Printpoint.Printrectangle();
	}
}

void Map::PushMap3_strawberry1()
{
	for (int i = 3; i < 19; i++)
	{

		map3_strawberry1.emplace_back(Printpoint((i + 6) * 2, 12));
		map3_strawberry1.emplace_back(Printpoint((i + 6) * 2, 13));
	}
	for (int i = 4; i < 17; i++)
	{
		map3_strawberry1.emplace_back(Printpoint((i + 6) * 2, 15));
	}
	for (int i = 4; i < 17; i++)
	{
		if (i != 6 && i != 10 && i != 14)
			map3_strawberry1.emplace_back(Printpoint((i + 6) * 2, 14));
		else
			map3_strawberry3.emplace_back(Printpoint((i + 6) * 2, 14));
	}
	for (int i = 4; i < 17; i++)
	{
		if (i != 7 && i != 11 && i != 15)
			map3_strawberry1.emplace_back(Printpoint((i + 6) * 2, 16));
		else
			map3_strawberry3.emplace_back(Printpoint((i + 6) * 2, 16));
	}
	map3_strawberry1.emplace_back(Printpoint(46, 14));
	map3_strawberry1.emplace_back(Printpoint(46, 16));
	for (int i = 5; i < 17; i++)
	{
		map3_strawberry1.emplace_back(Printpoint((i + 6) * 2, 17));
	}
	for (int i = 6; i < 16; i++)
	{
		if (i != 8 && i != 12)
			map3_strawberry1.emplace_back(Printpoint((i + 6) * 2, 18));
		else
			map3_strawberry3.emplace_back(Printpoint((i + 6) * 2, 18));
	}
	for (int i = 6; i < 16; i++)
	{
		if (i != 10 && i != 14)
			map3_strawberry1.emplace_back(Printpoint((i + 6) * 2, 19));
		else
			map3_strawberry3.emplace_back(Printpoint((i + 6) * 2, 19));
	}
	for (int i = 7; i < 15; i++)
	{
		map3_strawberry1.emplace_back(Printpoint((i + 6) * 2, 20));
	}
	for (int i = 8; i < 14; i++)
	{
		map3_strawberry1.emplace_back(Printpoint((i + 6) * 2, 21));
	}
	map3_strawberry1.emplace_back(Printpoint(32, 22));
	map3_strawberry1.emplace_back(Printpoint(34, 22));
	map3_strawberry1.emplace_back(Printpoint(26, 11));
	map3_strawberry1.emplace_back(Printpoint(28, 11));
	map3_strawberry1.emplace_back(Printpoint(30, 11));
	map3_strawberry1.emplace_back(Printpoint(34, 11));
	map3_strawberry1.emplace_back(Printpoint(36, 11));
	map3_strawberry1.emplace_back(Printpoint(38, 11));
	map3_strawberry1.emplace_back(Printpoint(42, 11));
	map3_strawberry1.emplace_back(Printpoint(42, 10));

}
void Map::PushMap3_strawberry2()
{
	map3_strawberry2.emplace_back(Printpoint(16, 12));
	map3_strawberry2.emplace_back(Printpoint(18, 11));
	map3_strawberry2.emplace_back(Printpoint(20, 11));
	map3_strawberry2.emplace_back(Printpoint(22, 12));
	map3_strawberry2.emplace_back(Printpoint(24, 12));
	map3_strawberry2.emplace_back(Printpoint(22, 11));
	map3_strawberry2.emplace_back(Printpoint(24, 11));
	map3_strawberry2.emplace_back(Printpoint(30, 9));
	map3_strawberry2.emplace_back(Printpoint(30, 10));
	map3_strawberry2.emplace_back(Printpoint(32, 9));
	map3_strawberry2.emplace_back(Printpoint(32, 10));
	map3_strawberry2.emplace_back(Printpoint(32, 11));
	for (int i = 8; i < 11; i++)
	{
		map3_strawberry2.emplace_back(Printpoint(34, i));
		map3_strawberry2.emplace_back(Printpoint(36, i));
		map3_strawberry2.emplace_back(Printpoint(38, i));
		map3_strawberry2.emplace_back(Printpoint(40, i + 1));
	}
	map3_strawberry2.emplace_back(Printpoint(42, 9));
	map3_strawberry2.emplace_back(Printpoint(44, 10));
	map3_strawberry2.emplace_back(Printpoint(46, 10));
	map3_strawberry2.emplace_back(Printpoint(44, 11));
	map3_strawberry2.emplace_back(Printpoint(46, 11));
	map3_strawberry2.emplace_back(Printpoint(48, 11));
	map3_strawberry2.emplace_back(Printpoint(50, 12));
	map3_strawberry2.emplace_back(Printpoint(50, 13));
	map3_strawberry2.emplace_back(Printpoint(22, 10));
	map3_strawberry2.emplace_back(Printpoint(24, 10));
	map3_strawberry2.emplace_back(Printpoint(26, 10));
	map3_strawberry2.emplace_back(Printpoint(40, 7));
	map3_strawberry2.emplace_back(Printpoint(28, 10));
	map3_strawberry2.emplace_back(Printpoint(20, 10));
	map3_strawberry2.emplace_back(Printpoint(18, 10));
	map3_strawberry2.emplace_back(Printpoint(30, 8));
	map3_strawberry2.emplace_back(Printpoint(28, 8));
	map3_strawberry2.emplace_back(Printpoint(26, 8));

}
void Map::printMap3_strawberry()
{
	for (auto& Printpoint : map3_strawberry1)
	{
		SetColor(DARKRED, LIGHTRED);
		Printpoint.Printrectangle();
	}
	for (auto& Printpoint : map3_strawberry2)
	{
		SetColor(DARKGREEN, WHITE);
		Printpoint.Printrectangle();
	}
	for (auto& Printpoint : map3_strawberry3)
	{
		SetColor(WHITE, LIGHTRED);
		Printpoint.Printcircle();
	}
}
void Map::IniMap1()//Cherry
{ //��������,ȷ�����꣬�������������
	for (int i = 0; i <= 21; i++)
		for (int j = 0; j <= 21; j++)
		{
			int attr = rand() % 3;
			if (Attr[i][j] != 7)
			{
				Attr[i][j] = attr;
				if (attr == 0)//·
				{
					iniMap1.emplace_back(Printpoint((i + 6) * 2, j + 6));
					SetColor(WHITE, WHITE);
					Printpoint((i + 6) * 2, j + 6).Printrectangle();
				}
				if (attr == 1)//ǽ
				{
					iniMap1.emplace_back(Printpoint((i + 6) * 2, j + 6));
					SetColor(DARKGREY, WHITE);
					Printpoint((i + 6) * 2, j + 6).Printcircle();
				}
				if (attr == 2)//�ϰ���
				{
					iniMap1.emplace_back(Printpoint((i + 6) * 2, j + 6));
					SetColor(DARKBLUE, WHITE);
					Printpoint((i + 6) * 2, j + 6).Printtree();
				}
			}
			else
				return;
		}
	//���ó�����
	for (int i = 0; i <= 3; i++)
		for (int j = 0; j < 3; j++)
		{
			Attr[i][j] = 0;
			iniMap1.emplace_back(Printpoint((i + 6) * 2, j + 6));
			SetColor(WHITE, WHITE);
			Printpoint((i + 6) * 2, j + 6).Printrectangle();
		}
	for (int i = 21; i >= 18; i--)
		for (int j = 21; j >= 18; j--)
		{
			Attr[i][j] = 0;
			iniMap1.emplace_back(Printpoint((i + 6) * 2, j + 6));
			SetColor(WHITE, WHITE);
			Printpoint((i + 6) * 2, j + 6).Printrectangle();
		}
	PushWall();
	PushBorder();
	PushMap1_cherry1();
	PushMap1_cherry2();
	PushMap1_cherry3();
	printMap1_cherry();
	printWall();
	PrintBorder();
	PushBlock();
	PrintBlock();
	PushPlayerStatus();
	PrintPlayerStatus(1);
	SetPosition(30 * 2, 21);
	SetPosition(30 * 2, 21);
	cout << "THE GAME";
	SetPosition(32 * 2, 23);
	cout << "IS";
	SetPosition(30 * 2, 25);
	cout << "GONING ON";
	PrintRule1();
}

void Map::IniMap2()//Peach
{
	for (int i = 0; i <= 21; i++)
		for (int j = 0; j <= 21; j++)
		{
			int attr = rand() % 3;
			if (Attr[i][j] != 7)
			{
				Attr[i][j] = attr;
				if (attr == 0)//·
				{
					iniMap1.emplace_back(Printpoint((i + 6) * 2, j + 6));
					SetColor(WHITE, WHITE);
					Printpoint((i + 6) * 2, j + 6).Printrectangle();
				}
				if (attr == 1)//ǽ
				{
					iniMap1.emplace_back(Printpoint((i + 6) * 2, j + 6));
					SetColor(DARKGREY, WHITE);
					Printpoint((i + 6) * 2, j + 6).Printcircle();
				}
				if (attr == 2)//�ϰ���
				{
					iniMap1.emplace_back(Printpoint((i + 6) * 2, j + 6));
					SetColor(LIGHTBLUE, WHITE);
					Printpoint((i + 6) * 2, j + 6).Printtree();
				}
			}
			else
				return;
		}
	//���ó�����
	for (int i = 0; i <= 3; i++)
		for (int j = 0; j < 3; j++)
		{
			Attr[i][j] = 0;
			iniMap1.emplace_back(Printpoint((i + 6) * 2, j + 6));
			SetColor(WHITE, WHITE);
			Printpoint((i + 6) * 2, j + 6).Printrectangle();
		}
	for (int i = 21; i >= 18; i--)
		for (int j = 21; j >= 18; j--)
		{
			Attr[i][j] = 0;
			iniMap1.emplace_back(Printpoint((i + 6) * 2, j + 6));
			SetColor(WHITE, WHITE);
			Printpoint((i + 6) * 2, j + 6).Printrectangle();
		}
	PushWall();
	PushBorder();
	PushMap2_peach1();
	PushMap2_peach2();
	printMap2_peach();
	printWall();
	PrintBorder();
	PushBlock();
	PrintBlock();
	PushPlayerStatus();
	PrintPlayerStatus(2);
	SetPosition(30 * 2, 21);
	SetPosition(30 * 2, 21);
	cout << "THE GAME";
	SetPosition(32 * 2, 23);
	cout << "IS";
	SetPosition(30 * 2, 25);
	cout << "GONING ON";
	PrintRule2();
}

void Map::IniMap3()
{
	for (int i = 0; i <= 21; i++)
		for (int j = 0; j <= 21; j++)
		{
			int attr = rand() % 3;
			if (Attr[i][j] != 7)
			{
				Attr[i][j] = attr;
				if (attr == 0)//·
				{
					iniMap1.emplace_back(Printpoint((i + 6) * 2, j + 6));
					SetColor(WHITE, WHITE);
					Printpoint((i + 6) * 2, j + 6).Printrectangle();
				}
				if (attr == 1)//ǽ
				{
					iniMap1.emplace_back(Printpoint((i + 6) * 2, j + 6));
					SetColor(DARKGREY, WHITE);
					Printpoint((i + 6) * 2, j + 6).Printcircle();
				}
				if (attr == 2)//�ϰ���
				{
					iniMap1.emplace_back(Printpoint((i + 6) * 2, j + 6));
					SetColor(LIGHTBLUE, WHITE);
					Printpoint((i + 6) * 2, j + 6).Printtree();
				}
			}
			else
				return;
		}
	//���ó�����
	for (int i = 0; i <= 3; i++)
		for (int j = 0; j < 3; j++)
		{
			Attr[i][j] = 0;
			iniMap1.emplace_back(Printpoint((i + 6) * 2, j + 6));
			SetColor(WHITE, WHITE);
			Printpoint((i + 6) * 2, j + 6).Printrectangle();
		}
	for (int i = 21; i >= 18; i--)
		for (int j = 21; j >= 18; j--)
		{
			Attr[i][j] = 0;
			iniMap1.emplace_back(Printpoint((i + 6) * 2, j + 6));
			SetColor(WHITE, WHITE);
			Printpoint((i + 6) * 2, j + 6).Printrectangle();
		}
	PushWall();
	PushBorder();
	PushMap3_strawberry1();
	PushMap3_strawberry2();
	printMap3_strawberry();
	printWall();
	PrintBorder();
	PushBlock();
	PrintBlock();
	PushPlayerStatus();
	PrintPlayerStatus(3);
	SetPosition(30 * 2, 21);
	cout << "THE GAME";
	SetPosition(32 * 2, 23);
	cout << "IS";
	SetPosition(30 * 2, 25);
	cout << "GONING ON";
	PrintRule3();
}

void Map::PushPlayerStatus()
{
	Player1Status.emplace_back(Printpoint(30 * 2, 6));
	Player1Status.emplace_back(Printpoint(29 * 2, 8));
	Player1Status.emplace_back(Printpoint(29 * 2, 10));
	Player2Status.emplace_back(Printpoint(30 * 2, 13));
	Player2Status.emplace_back(Printpoint(29 * 2, 15));
	Player2Status.emplace_back(Printpoint(29 * 2, 17));
}
void Map::PrintPlayerStatus(int maptype)
{
	SetColor(DARKBLUE, WHITE);
	Player1Status[0].PrintPlayer1();
	SetColor(DARKBLUE, WHITE);
	Player2Status[0].PrintPlayer2();
	if (maptype == 1)
	{
		SetColor(DARKBLUE, WHITE);
		Player1Status[1].Printbomb();
		Player1Status[2].PrintSuperBomb();
		Player2Status[1].Printbomb();
		Player2Status[2].PrintSuperBomb();
	}
	if (maptype == 2)
	{
		SetColor(DARKBLUE, WHITE);
		Player1Status[1].Printbomb();
		Player1Status[2].PrintPoison();
		Player2Status[1].Printbomb();
		Player2Status[2].PrintPoison();
	}
	if (maptype == 3)
	{
		SetColor(DARKBLUE, WHITE);
		Player1Status[1].Printbomb();
		Player1Status[2].PrintStealthBomb();
		Player2Status[1].Printbomb();
		Player2Status[2].PrintStealthBomb();
	}

}

void Map::PrintRule1()
{
	SetPosition(37 * 2, 7);
	cout << "  Cherry Bomb��";
	SetPosition(38 * 2, 9);
	cout << "Player1��IKJL�����ƶ����� ";
	SetPosition(38 * 2, 11);
	cout << "�ո񡪡���ͨը���� 0����ȫ��ը����";
	SetPosition(37 * 2, 13);
	cout << "  Player2��WSAD�����ƶ�����";
	SetPosition(38 * 2, 15);
	cout << "TAB������ͨը���� 1����ȫ��ը����";
	SetPosition(38 * 2, 17);
	cout << "��ͨը���ѣ�ֻ��ը���ϰ���";
	SetPosition(37 * 2, 19);
	cout << "  ȫ��ը���������������ж�����ը��";
}
void Map::PrintRule2()
{
	SetPosition(37 * 2, 7);
	cout << "  Peach Bomb��";
	SetPosition(38 * 2, 9);
	cout << "Player1��IKJL�����ƶ����� ";
	SetPosition(38 * 2, 11);
	cout << "�ո񡪡���ͨը���� 0������ҩ��";
	SetPosition(37 * 2, 13);
	cout << "  Player2��WSAD�����ƶ�����";
	SetPosition(38 * 2, 15);
	cout << "TAB������ͨը���� 1������ҩ��";
	SetPosition(38 * 2, 17);
	cout << "��ͨը���ѣ�ֻ��ը���ϰ���";
	SetPosition(37 * 2, 19);
	cout << "   ��ҩ���� ��ұ���ס";
}
void Map::PrintRule3()
{
	SetPosition(37 * 2, 7);
	cout << " Strawberry Bomb��";
	SetPosition(38 * 2, 9);
	cout << "Player1��IKJL�����ƶ����� ";
	SetPosition(38 * 2, 11);
	cout << "�ո񡪡���ͨը����, 0��������ը����";
	SetPosition(37 * 2, 13);
	cout << "  Player2��WSAD�����ƶ�����";
	SetPosition(38 * 2, 15);
	cout << "TAB������ͨը����,1��������ը����";
	SetPosition(38 * 2, 17);
	cout << "��ͨը���ѣ�ֻ��ը���ϰ���";
	SetPosition(37 * 2, 19);
	cout << "   ����ը���裺����10���ը��ӵ����ͨը����ը��";
}
