﻿#include<Windows.h>
#include"SetWindows.h"
#include<iostream>
#include"Bombman.h"
#include"Map.h"
#include"Controller.h"
#include"Initialinterface.h"
#include<stdio.h>
#include<mutex>
#include<thread>
#include<condition_variable>
#include <mmsystem.h>
#pragma comment(lib, "winmm.lib")
using namespace std;
int main()
{
	SetWinSize(1, 1, 115, 40);
	/*Initialinterface* start = new Initialinterface();*/
	SetFont(20);
	Controller c;
	c.Game();
}

