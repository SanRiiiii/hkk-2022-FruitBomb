#include "Bombman.h"
#include<time.h>
#include"SetWindows.h"
#include<iostream>
#include<deque>
#include"Map.h"
#include"conio.h"
#include<mutex>
#include<thread>
#include<functional>
#include<ctime>
#include<cstdlib>
#include <mmsystem.h>
#pragma comment(lib, "winmm.lib")
extern atomic<bool> ifGameEnded = 0;
extern atomic<int>Bombflag = 0;
mutex mtxAttr;//����attr�ᱻ�����߳�ͬʱ��д
mutex mtxBombRange;
mutex mtxPlayer;
mutex mtxBomb;
extern int Attr[22][22];

Bombman::Bombman()
{
	bombs.push_back(Bomb(0));
	bombs.push_back(Bomb(0));
	bombs.push_back(Bomb(0));
	bombs.push_back(Bomb(0));
	m_BombAmount = 4;
}
void Bombman::Initialbombman2()
{
	bombman.emplace_back(Printpoint(6 * 2, 6));
	for (auto& Printpoint : bombman)
	{
		SetColor(DARKGREY, WHITE);
		Printpoint.Printstar();
	}
	Player2Status.emplace_back(Printpoint(30 * 2, 15));
	Player2Status.emplace_back(Printpoint(30 * 2, 17));
}
void Bombman::Initialbombman1()
{
	bombman.emplace_back(Printpoint(27 * 2, 27));
	for (auto& Printpoint : bombman)
	{
		SetColor(DARKGREY, WHITE);
		Printpoint.Printstar();
	}
	Player1Status.emplace_back(Printpoint(30 * 2, 8));
	Player1Status.emplace_back(Printpoint(30 * 2, 10));
}
bool Bombman::Judge(int a, int b)//�ж������Ӧ����������������ǲ���0
{
	extern int Attr[22][22];
	if (Attr[a][b] == 1 || Attr[a][b] == 2 || Attr[a][b] == 7)
		return false;
	else
		return true;
}
bool Bombman::Edge(int a, int b)
{
	return (a < 56 && b < 28 && a > 10 && b > 5);
}
bool Bombman::getKey()
{
	lock_guard<mutex>locker(mtxPlayer);
	return m_key;
}
void Bombman::setKey(int i)
{
	lock_guard<mutex>locker(mtxPlayer);
	m_key = i;
}
void Bombman::Changedirection1()
{
	unique_lock<mutex>locker(mtxPlayer);
	char ch;
	while (1)
	{
		if (_kbhit())
		{
			ch = _getch();
			switch (ch)
			{
			case'i'://���ƶ���
				direction = Direction::UP;
				m_key = 1;
				break;
			case 'k'://���ƶ���
				direction = Direction::DOWN;
				m_key = 1;
				break;
			case 'j'://���ƶ���
				direction = Direction::LEFT;
				m_key = 1;
				break;
			case 'l'://���ƶ���
				direction = Direction::RIGHT;
				m_key = 1;
				break;
			case 32:
				direction = Direction::NORMALBOMB;
				m_key = 1;
				break;
			case 48:
				direction = Direction::PROPS;
				m_key = 1;
				break;
			case 27://esc�����˳�
				break;
			default:
				m_key = 0;
				break;
			}
			return;
		}

	}
}
void Bombman::Changedirection2()
{
	unique_lock<mutex>locker(mtxPlayer);
	char ch;
	while (1)
	{
		if (_kbhit())
		{
			ch = _getch();
			switch (ch)
			{
			case 'w'://���ƶ���
				direction = Direction::UP;
				m_key = 1;
				break;
			case 's'://���ƶ���
				direction = Direction::DOWN;
				m_key = 1;
				break;
			case 'a'://���ƶ���
				direction = Direction::LEFT;
				m_key = 1;
				break;
			case 'd'://���ƶ���
				direction = Direction::RIGHT;
				m_key = 1;
				break;
			case 9://TAB������ͨը��
				direction = Direction::NORMALBOMB;
				m_key = 1;
				break;
			case 49:
				direction = Direction::PROPS;
				m_key = 1;
				break;
			case 27://esc�����˳�
				break;
			default:
				m_key = 0;
				break;
			}
			return;
		}
	}
}
//�����ƶ��жϣ����߻�ȡ�ж�
void Bombman::Action(int maptype, int player)//�������ˣ���
{
	unique_lock<mutex>locker(mtxPlayer);
	unique_lock<mutex>locker1(mtxAttr);
	unique_lock<mutex>locker2(mtxBomb);
	extern int Attr[22][22];
	int x, y;
	if (Attr[bombman.back().GetX() / 2 - 6][bombman.back().GetY() - 6] == 4)
	{
		locker.unlock();
		Sleep(3 * 1000);
		locker.lock();
	}
	switch (direction)
	{
	case Direction::UP:
	{
		x = bombman.back().GetX();
		y = bombman.back().GetY() - 1;
		if (Judge(x / 2 - 6, y - 6) && Edge(x, y))
		{
			bombman.emplace_back(Printpoint(x, y));
			GetProps(x / 2 - 6, y - 6);
			if (Attr[x / 2 - 6][y - 6] == 4)
			{
				SetColor(DARKGREEN, BLACK);
				bombman.back().Printstar();
				bombman.front().Clear();
				Sleep(3 * 1000);
			}
			Attr[x / 2 - 6][y - 6] = 10 * player;//��������,˵����˭
			bombman.back().Printstar();
			bombman.front().Clear();
			bombman.pop_front();
			Attr[x / 2 - 6][y - 6 + 1] = 0;
			break;
		}
		else break;
	}
	case Direction::DOWN:
	{
		x = bombman.back().GetX();
		y = bombman.back().GetY() + 1;
		if (Judge(x / 2 - 6, y - 6) && Edge(x, y))
		{
			bombman.emplace_back(Printpoint(x, y));
			GetProps(x / 2 - 6, y - 6);
			if (Attr[x / 2 - 6][y - 6] == 4)
			{
				SetColor(DARKGREEN, BLACK);
				bombman.back().Printstar();
				bombman.front().Clear();
				Sleep(3 * 1000);
			}
			Attr[x / 2 - 6][y - 6] = 10 * player;//��������
			bombman.back().Printstar();
			bombman.front().Clear();
			bombman.pop_front();
			Attr[x / 2 - 6][y - 6 - 1] = 0;
			break;
		}
		else break;
	}
	case Direction::LEFT:
	{
		x = bombman.back().GetX() - 2;
		y = bombman.back().GetY();
		if (Judge(x / 2 - 6, y - 6) && Edge(x, y))
		{
			bombman.emplace_back(Printpoint(x, y));
			GetProps(x / 2 - 6, y - 6);
			if (Attr[x / 2 - 6][y - 6] == 4)
			{
				SetColor(DARKGREEN, BLACK);
				bombman.back().Printstar();
				bombman.front().Clear();
				Sleep(3 * 1000);
			}
			Attr[x / 2 - 6][y - 6] = 10 * player;//��������
			bombman.back().Printstar();
			bombman.front().Clear();
			bombman.pop_front();
			Attr[(x + 2) / 2 - 6][y - 6] = 0;
			break;
		}
		else break;
	case Direction::RIGHT:
	{
		x = bombman.back().GetX() + 2;
		y = bombman.back().GetY();
		if (Judge(x / 2 - 6, y - 6) && Edge(x, y))
		{
			bombman.emplace_back(Printpoint(x, y));
			GetProps(x / 2 - 6, y - 6);
			if (Attr[x / 2 - 6][y - 6] == 4)
			{
				SetColor(DARKGREEN, BLACK);
				bombman.back().Printstar();
				bombman.front().Clear();
				Sleep(3 * 1000);
			}
			Attr[x / 2 - 6][y - 6] = 10 * player;//��������
			bombman.back().Printstar();
			bombman.front().Clear();
			bombman.pop_front();
			Attr[(x - 2) / 2 - 6][y - 6] = 0;
			break;
		}
		else break;
	}
	case Direction::NORMALBOMB:
	{
		DropNormalBomb(maptype);
		break;
	}
	case Direction::PROPS:
	{
		DropProps();
		break;
	}
	default:
		break;
	}
	}
}
//ʹ��ͨ��ը��
void Bombman::DropNormalBomb(int maptype)
{
	if (this->m_BombAmount > 0)
	{
		for (auto& Bomb : bombs)
		{
			if (Bomb.getStatus() != 1)
			{
				Bomb.setStatus(1);//����ը�����1
				this->m_BombAmount--;//�ö����ը����-1
				Bomb.setPosition(bombman.back().GetX(), bombman.back().GetY());//��ը���˴�ʱ��λ�ø�ը������
				thread BombThread(&Bomb::normalBomb, Bomb, maptype);
				BombThread.detach();
				bombs.pop_front();
				break;
			}
		}
	}
}
//ʹ�õ���
void StrawBerryBombman::DropProps()
{

	if (this->m_StealthBombAmount > 0)
	{
		for (auto& Bomb : stealthbombs)
		{
			if (Bomb.getStatus() != 1)
			{
				Bomb.setStatus(1);//����ը�����1
				this->m_StealthBombAmount--;//�ö����ը����-1
				Bomb.setPosition(bombman.back().GetX(), bombman.back().GetY());//��ը���˴�ʱ��λ�ø�ը������
				thread BombThread(&Bomb::stealthBomb, Bomb);
				BombThread.detach();
				stealthbombs.pop_front();
				break;
			}
		}
	}

}
void CherryBombman::DropProps()//���ߣ�����ը��
{

	if (this->m_SuperBombAmount > 0)
	{
		for (auto& Bomb : SuperBomb)
		{
			if (Bomb.getStatus() != 1)
			{
				Bomb.setStatus(1);//����ը�����1
				this->m_SuperBombAmount--;//�ö����ը����-1
				Bomb.setPosition(bombman.back().GetX(), bombman.back().GetY());//��ը���˴�ʱ��λ�ø�ը������
				thread BombThread(&Bomb::superBomb, Bomb);
				BombThread.detach();
				SuperBomb.pop_front();
				break;
			}
		}
	}

}
void PeachBombman::DropProps()//���ߣ���ҩ
{

	if (this->m_PoisonAmount > 0)
	{
		for (auto& Bomb : poison)
		{
			if (Bomb.getStatus() != 1)
			{
				Bomb.setStatus(1);//����ը�����1
				this->m_PoisonAmount--;//�ö����ը����-1
				Bomb.setPosition(bombman.back().GetX(), bombman.back().GetY());//��ը���˴�ʱ��λ�ø�ը������
				thread BombThread(&Bomb::poison, Bomb);
				BombThread.detach();
				poison.pop_front();
				break;
			}
		}
	}

}
//һ���Ӻ�ÿ��10������ˢ��һ��ը�������̺߳���
void Bombman::BombCreate()
{
	unique_lock<mutex>locker1(mtxBomb);
	m_BombAmount++;
	bombs.push_back(Bomb(0));
}
//����ӵ�ͼ�ϻ�ȡ����
void CherryBombman::GetProps(int x, int y)
{
	if (Attr[x][y] == 6)
	{
		m_SuperBombAmount++;
		SuperBomb.emplace_back(Bomb(0));
		return;
	}
	return;
}
void PeachBombman::GetProps(int x, int y)
{
	if (Attr[x][y] == 5)
	{
		m_PoisonAmount++;
		poison.emplace_back(Bomb(0));
		return;
	}
	return;
}
void StrawBerryBombman::GetProps(int x, int y)
{
	if (Attr[x][y] == 3)
	{
		m_StealthBombAmount++;
		stealthbombs.emplace_back(Bomb(0));
		return;
	}
	return;
}
//����ӵ�ͼ�ϻ�ȡ������������
void Bomb::PropsPrint(Printpoint p, int maptype)
{
	if (maptype == 2)
	{
		SetColor(DARKGREEN, WHITE);
		p.PrintPoison();
		Attr[p.GetX() / 2 - 6][p.GetY() - 6] = 5;//��ҩ��ȡ
	}
	else if (maptype == 1)
	{
		SetColor(DARKRED, WHITE);
		p.PrintSuperBomb();
		Attr[p.GetX() / 2 - 6][p.GetY() - 6] = 6;//����ը��
	}
	else if (maptype == 3)
	{
		SetColor(LIGHTGREY, WHITE);
		p.PrintStealthBomb();
		Attr[p.GetX() / 2 - 6][p.GetY() - 6] = 3;//����ը��
	}
}
//ը��:��û������ɵ��ߵĻ���
void Bomb::normalBomb(int maptype)
{
	unique_lock<mutex>locker(mtxBomb);
	this->printBomb();
	locker.unlock();
	Sleep(1000);
	this->printClear();
	for (int i = 3; i >= 0; i--)
	{
		locker.lock();
		SetColor(LIGHTRED, WHITE);
		SetPosition(m_point.GetX(), m_point.GetY());
		cout << " " << i << endl;
		locker.unlock();
		Sleep(1000);
	}
	unique_lock<mutex>locker1(mtxAttr);
	vector<Printpoint>printExplosion;
	extern int Attr[22][22];
	int x = m_point.GetX() / 2 - 6;
	int y = m_point.GetY() - 6;
	//��
	for (int i = 0; i <= CaculateExplosionRange(); i++)
	{
		if (m_point.GetX() + 2 * i < 56)//�߽��ж�
		{
			if (Attr[x + i][y] != 7)
				printExplosion.emplace_back(Printpoint(m_point.GetX() + 2 * i, m_point.GetY()));
			else break;
		}
	}
	//��
	for (int i = 0; i <= CaculateExplosionRange(); i++)
	{
		if (m_point.GetX() - 2 * i > 10)
		{
			if (Attr[x - i][y] != 7)
				printExplosion.emplace_back(Printpoint(m_point.GetX() - 2 * i, m_point.GetY()));
			else break;
		}
	}
	//��
	for (int i = 0; i <= CaculateExplosionRange(); i++)
	{
		if (m_point.GetY() + i < 28)
		{
			if (Attr[x][y + i] != 7)
				printExplosion.emplace_back(Printpoint(m_point.GetX(), m_point.GetY() + i));
			else break;
		}
	}
	//��
	for (int i = 0; i <= CaculateExplosionRange(); i++)
	{
		if (m_point.GetY() - i > 5)
		{
			if (Attr[x][y - i] != 7)
				printExplosion.emplace_back(Printpoint(m_point.GetX(), m_point.GetY() - i));
			else break;
		}
	}
	locker1.unlock();
	locker.lock();
	for (auto& Printpoint : printExplosion)
	{
		if (Attr[Printpoint.GetX() / 2 - 6][Printpoint.GetY() - 6] == 10)
			Bombflag = 1;
		else if (Attr[Printpoint.GetX() / 2 - 6][Printpoint.GetY() - 6] == 20)
			Bombflag = 2;
		SetColor(DARKRED, LIGHTRED);
		Printpoint.Printrectangle();
	}
	PlaySound(TEXT("9882.wav"), NULL, SND_FILENAME | SND_ASYNC);
	Sleep(1500);
	PlaySound(TEXT("������� (���Ȥ� �ޤ���) - �ɥ��Х���������� (��������Chorogons).wav"), NULL, SND_FILENAME | SND_ASYNC);
	Sleep(100);
	for (auto& Printpoint : printExplosion)
	{
		Attr[Printpoint.GetX() / 2 - 6][Printpoint.GetY() - 6] = 0;
		SetColor(WHITE, WHITE);
		Printpoint.Clear();
	}
	for (auto& Printpoint : printExplosion)//��ը�����ɵ���
	{
		int temp = rand() % 30 + 1;
		if (temp == 15)
		{
			PropsPrint(Printpoint, maptype);
		}
	}
	if (Bombflag == 1 || Bombflag == 2)//��������ڱ�ը��Χ����ը��Ч
		ifGameEnded = 1;
}
void Bomb::stealthBomb()
{
	unique_lock<mutex>locker(mtxBomb);
	int x = m_point.GetX() / 2 - 6;
	int y = m_point.GetY() - 6;
	SetColor(LIGHTGREY, WHITE);
	this->printBomb();
	locker.unlock();
	Sleep(1000);
	this->printClear();
	vector<Printpoint>printHint;
	printHint.emplace_back(Printpoint(5 * 2, y + 6));
	printHint.emplace_back(Printpoint(28 * 2, y + 6));
	printHint.emplace_back(Printpoint((x + 6) * 2, 5));
	printHint.emplace_back(Printpoint((x + 6) * 2, 28));
	//����ǽ����ʾ
	for (auto& Printpoint : printHint)
	{
		locker.lock();
		SetColor(DARKRED, WHITE);
		Printpoint.Printrectangle();
		locker.unlock();
	}
	Sleep(10 * 1000);
	//����ǽ�ָ�
	for (auto& Printpoint : printHint)
	{
		SetColor(LIGHTYELLOW, DARKBLUE);
		Printpoint.Printrectangle();
	}
	for (int i = 3; i >= 0; i--)
	{
		locker.lock();
		SetColor(DARKRED, BLACK);
		SetPosition(m_point.GetX(), m_point.GetY());
		cout << " " << i << endl;
		locker.unlock();
		Sleep(300);
	}
	vector<Printpoint>printExplosion;
	unique_lock<mutex>locker1(mtxAttr);
	extern int Attr[22][22];
	//��
	for (int i = 0; i <= CaculateExplosionRange(); i++)
	{
		if (m_point.GetX() + 2 * i < 56)//�߽��ж�
		{
			if (Attr[x + i][y] != 7)
				printExplosion.emplace_back(Printpoint(m_point.GetX() + 2 * i, m_point.GetY()));
			else break;
		}
	}
	//��
	for (int i = 0; i <= CaculateExplosionRange(); i++)
	{
		if (m_point.GetX() - 2 * i > 10)
		{
			if (Attr[x - i][y] != 7)
				printExplosion.emplace_back(Printpoint(m_point.GetX() - 2 * i, m_point.GetY()));
			else break;
		}
	}
	//��
	for (int i = 0; i <= CaculateExplosionRange(); i++)
	{
		if (m_point.GetY() + i < 28)
		{
			if (Attr[x][y + i] != 7)
				printExplosion.emplace_back(Printpoint(m_point.GetX(), m_point.GetY() + i));
			else break;
		}
	}
	//��
	for (int i = 0; i <= CaculateExplosionRange(); i++)
	{
		if (m_point.GetY() - i > 5)
		{
			if (Attr[x][y - i] != 7)
				printExplosion.emplace_back(Printpoint(m_point.GetX(), m_point.GetY() - i));
			else break;
		}
	}
	locker.lock();
	for (auto& Printpoint : printExplosion)
	{
		if (Attr[Printpoint.GetX() / 2 - 6][Printpoint.GetY() - 6] == 10)
			Bombflag = 1;
		else if (Attr[Printpoint.GetX() / 2 - 6][Printpoint.GetY() - 6] == 20)
			Bombflag = 2;
		SetColor(DARKRED, LIGHTRED);
		Printpoint.Printrectangle();
	}
	PlaySound(TEXT("9882.wav"), NULL, SND_FILENAME | SND_ASYNC);
	Sleep(1500);
	PlaySound(TEXT("������� (���Ȥ� �ޤ���) - �ɥ��Х���������� (��������Chorogons).wav"), NULL, SND_FILENAME | SND_ASYNC);
	Sleep(100);
	for (auto& Printpoint : printExplosion)
	{
		Attr[Printpoint.GetX() / 2 - 6][Printpoint.GetY() - 6] = 0;
		SetColor(WHITE, WHITE);
		Printpoint.Clear();
	}
	for (auto& Printpoint : printExplosion)
	{
		int temp = rand() % 30 + 1;
		if (temp == 10)
		{
			PropsPrint(Printpoint, 3);
		}
	}
	if (Bombflag == 1 || Bombflag == 2)//��������ڱ�ը��Χ����ը��Ч
		ifGameEnded = 1;
}
void Bomb::poison()
{
	unique_lock<mutex>locker(mtxBomb);
	SetColor(DARKGREEN, WHITE);
	this->printPoison();
	locker.unlock();
	Sleep(1000);
	locker.lock();
	this->printClear();
	locker.unlock();
	for (int i = 5; i >= 0; i--)
	{
		locker.lock();
		SetColor(DARKGREEN, WHITE);
		SetPosition(m_point.GetX(), m_point.GetY());
		cout << " " << i << endl;
		locker.unlock();
		Sleep(1000);
	}
	unique_lock<mutex>locker1(mtxAttr);
	vector<Printpoint>printExplosion;
	extern int Attr[22][22];
	int x = m_point.GetX() / 2 - 6;
	int y = m_point.GetY() - 6;
	for (int i = 0; i <= CaculateExplosionRange(); i++)
	{
		if (m_point.GetX() + 2 * i < 56)//�߽��ж�
		{
			if (Attr[x + i][y] != 7)
				printExplosion.emplace_back(Printpoint(m_point.GetX() + 2 * i, m_point.GetY()));
			else break;
		}
	}
	//��
	for (int i = 0; i <= CaculateExplosionRange(); i++)
	{
		if (m_point.GetX() - 2 * i > 10)
		{
			if (Attr[x - i][y] != 7)
				printExplosion.emplace_back(Printpoint(m_point.GetX() - 2 * i, m_point.GetY()));
			else break;
		}
	}
	//��
	for (int i = 0; i <= CaculateExplosionRange(); i++)
	{
		if (m_point.GetY() + i < 28)
		{
			if (Attr[x][y + i] != 7)
				printExplosion.emplace_back(Printpoint(m_point.GetX(), m_point.GetY() + i));
			else break;
		}
	}
	//��
	for (int i = 0; i <= CaculateExplosionRange(); i++)
	{
		if (m_point.GetY() - i > 5)
		{
			if (Attr[x][y - i] != 7)
				printExplosion.emplace_back(Printpoint(m_point.GetX(), m_point.GetY() - i));
			else break;
		}
	}
	locker.lock();
	for (auto& Printpoint : printExplosion)
	{
		SetColor(DARKGREEN, LIGHTGREEN);
		if (Attr[Printpoint.GetX() / 2 - 6][Printpoint.GetY() - 6] == 10 || Attr[Printpoint.GetX() / 2 - 6][Printpoint.GetY() - 6] == 20)
			Printpoint.Printstar();
		else
			Printpoint.Printrectangle();
		Attr[Printpoint.GetX() / 2 - 6][Printpoint.GetY() - 6] = 4;//������·̽�������4��ס3��
	}
	locker.unlock();
	locker1.unlock();
	PlaySound(TEXT("9882.wav"), NULL, SND_FILENAME | SND_ASYNC);
	Sleep(1500);
	PlaySound(TEXT("������� (���Ȥ� �ޤ���) - �ɥ��Х���������� (��������Chorogons).wav"), NULL, SND_FILENAME | SND_ASYNC);
	Sleep(3 * 1000);
	locker.lock();
	locker1.lock();
	for (auto& Printpoint : printExplosion)
	{
		if (Attr[Printpoint.GetX() / 2 - 6][Printpoint.GetY() - 6] == 10 || Attr[Printpoint.GetX() / 2 - 6][Printpoint.GetY() - 6] == 20)
			Printpoint.Printstar();
		else
		{
			SetColor(WHITE, WHITE);
			Printpoint.Clear();
		}
		Attr[Printpoint.GetX() / 2 - 6][Printpoint.GetY() - 6] = 0;
	}

}
void Bomb::superBomb()
{
	unique_lock<mutex>locker(mtxBomb);
	PropsPrint(m_point, 1);
	locker.unlock();
	Sleep(1000);
	locker.lock();
	this->printClear();
	locker.unlock();
	for (int i = 3; i >= 0; i--)
	{
		locker.lock();
		SetColor(ROSERED, WHITE);
		SetPosition(m_point.GetX(), m_point.GetY());
		cout << " " << i << endl;
		locker.unlock();
		Sleep(1000);
	}
	int x = m_point.GetX();
	int y = m_point.GetY();
	vector<Printpoint>printExplosion;
	unique_lock<mutex>locker1(mtxAttr);
	for (int i = 6 * 2; i <= 27 * 2; i++)
		printExplosion.emplace_back(Printpoint(i, y));
	for (int j = 6; j <= 27; j++)
		printExplosion.emplace_back((Printpoint(x, j)));
	locker.lock();
	for (auto& Printpoint : printExplosion)
	{
		if (Attr[Printpoint.GetX() / 2 - 6][Printpoint.GetY() - 6] == 10)
			Bombflag = 1;
		else if (Attr[Printpoint.GetX() / 2 - 6][Printpoint.GetY() - 6] == 20)
			Bombflag = 2;
		SetColor(DARKRED, LIGHTRED);
		Printpoint.Printrectangle();
	}
	Sleep(100);
	for (auto& Printpoint : printExplosion)
	{
		SetColor(WHITE, WHITE);
		Attr[Printpoint.GetX() / 2 - 6][Printpoint.GetY() - 6] = 0;
		Printpoint.Clear();
	}
	for (auto& Printpoint : printExplosion)//��ը�����ɵ���
	{
		int temp = rand() % 100;
		if (temp == 50)
		{
			PropsPrint(Printpoint, 1);
		}
	}
	if (Bombflag == 1 || Bombflag == 2)//��������ڱ�ը��Χ����ը��Ч
		ifGameEnded = 1;
}

int Bomb::CaculateExplosionRange()
{
	lock_guard<mutex> mtx(mtxBombRange);
	int Rage = 1;
	long TimePast = clock();
	if (TimePast <= 1000 * 30)
		Rage = 1;
	else if (TimePast <= 1000 * 60)
		Rage = 2;
	else if (TimePast <= 1000 * 80)
		Rage = 3;
	else if (TimePast <= 1000 * 90)
		Rage = 4;
	else if (TimePast <= 1000 * 120)
		Rage = 6;
	else if (TimePast <= 240)
		Rage = 8;
	else Rage = 10;
	return Rage;
}
//ˢ����ҵ�����
void Bombman::showPlayerStatus(int map, int player)
{
	unique_lock<mutex>locker(mtxPlayer);
	unique_lock<mutex>locker1(mtxBomb);
	if (map == 1)
	{
		if (player == 1)
		{
			SetColor(DARKBLUE, WHITE);
			Player1Status[0].PrintData(m_BombAmount);
			Player1Status[1].PrintData(m_SuperBombAmount);
		}
		else if (player == 2)
		{

			SetColor(DARKBLUE, WHITE);
			Player2Status[0].PrintData(m_BombAmount);
			Player2Status[1].PrintData(m_SuperBombAmount);
		}
	}
	if (map == 2)
	{
		if (player == 1)
		{
			SetColor(DARKBLUE, WHITE);
			Player1Status[0].PrintData(m_BombAmount);
			Player1Status[1].PrintData(m_PoisonAmount);
		}
		else if (player == 2)
		{

			SetColor(DARKBLUE, WHITE);
			Player2Status[0].PrintData(m_BombAmount);
			Player2Status[1].PrintData(m_PoisonAmount);
		}
	}
	if (map == 3)
	{
		if (player == 1)
		{
			SetColor(DARKBLUE, WHITE);
			Player1Status[0].PrintData(m_BombAmount);
			Player1Status[1].PrintData(m_StealthBombAmount);
		}
		else if (player == 2)
		{

			SetColor(DARKBLUE, WHITE);
			Player2Status[0].PrintData(m_BombAmount);
			Player2Status[1].PrintData(m_StealthBombAmount);
		}
	}
}
