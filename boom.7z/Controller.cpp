#include "Controller.h"
#include<iostream>
#include<conio.h>
#include<Windows.h>
#include<time.h>
#include"Initialinterface.h"
#include"Map.h"
#include"Bombman.h"
#include"SetWindows.h"
#include<mutex>
#include<thread>
#include<condition_variable>
#include<cstdlib>
#include <mmsystem.h>
#pragma comment(lib, "winmm.lib")
using namespace std;
mutex mtxPlayers;
extern int Attr[22][22];
extern atomic<bool> ifGameEnded;
extern atomic<int>Bombflag;
condition_variable cv;
atomic<bool> flag = 1;
int color1;
int color2;
int key = 0;

void Controller::Start()//�׽������Ļ
{
	PlaySound(TEXT("���x �� (�錄�ʤ� ������) - Relax��������`�� (Relax������).wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
	SetWinSize(1, 1, 115, 40);
	system("color E0");//���ý��汳��ɫ��������ɫ
	SetFont(20);
	HideCursor(true);//���ع��
	SetWinSize(1, 1, 115, 40);//���ڴ�С
	Initialinterface* start = new Initialinterface();
	start->PrintText();//��Ļ����
	SetPosition(38, 30);
	SetColor(BLACK, LIGHTYELLOW);
	cout << "Press any key to start����";
	system("pause");
}
void Controller::Select()
{
	system("cls");
	system("color F7");
	Initialinterface* start = new Initialinterface();
	start->PrintStart();
	/*��ʼ�������ͼѡ��*/
	SetColor(BLACK, WHITE);
	SetPosition(43, 10);
	cout << "��ѡ����ĵ�ͼ��";
	SetPosition(40, 13);
	cout << "���·���ѡ�񣬻س�ȷ��";
	SetPosition(44, 17);
	SetColor(BLACK, LIGHTYELLOW);
	cout << "Cherry Bomb!";
	SetPosition(44, 21);
	SetColor(BLACK, WHITE);
	cout << "Peach Bomb!";
	SetPosition(44, 25);
	SetColor(BLACK, WHITE);
	cout << "Strawberry Bomb!";
	SetPosition(44, 29);


	/*���·���ѡ��ģ��*/
	int ch;
	key = 1;
	bool flag = false;
	while ((ch = _getch()))
	{
		switch (ch)
		{
		case 72://�ϼ�
			if (key > 1)
			{
				switch (key)
				{
				case 2:
					SetPosition(44, 17);
					SetColor(BLACK, LIGHTYELLOW);
					cout << "Cherry Bomb!";

					SetPosition(44, 21);
					SetColor(BLACK, WHITE);
					cout << "Peach Bomb!";
					--key;
					break;
				case 3:
					SetPosition(44, 21);
					SetColor(BLACK, LIGHTYELLOW);
					cout << "Peach Bomb!";

					SetPosition(44, 25);
					SetColor(BLACK, WHITE);
					cout << "Strawberry Bomb!";
					--key;
					break;
				}
			}
			break;
		case 80://�¼�
			if (key < 4)
			{
				switch (key)
				{
				case 1:
					SetPosition(44, 21);
					SetColor(BLACK, LIGHTYELLOW);
					cout << "Peach Bomb!";

					SetPosition(44, 17);
					SetColor(BLACK, WHITE);
					cout << "Cherry Bomb!";
					++key;
					break;
				case 2:
					SetPosition(44, 25);
					SetColor(BLACK, LIGHTYELLOW);
					cout << "Strawberry Bomb!";

					SetPosition(44, 21);
					SetColor(BLACK, WHITE);
					cout << "Peach Bomb!";
					++key;
					break;
				}
			}
			break;
		case 13://�س�ȷ��
			flag = true;
			break;
		default:
			break;
		}
		if (flag)
			break;
	}
}
void Controller::Color1()
{
	system("cls");
	system("color F0");
	Initialinterface* start = new Initialinterface();
	start->PrintStart();
	/*��ʼ�������ͼѡ��*/
	SetColor(PURPLE, LIGHTYELLOW);
	SetPosition(24, 17);
	cout << "����";
	SetColor(DARKYELLOW, LIGHTGREY);
	SetPosition(38, 17);
	cout << "����";
	SetColor(MINT, LIGHTGREY);
	SetPosition(52, 17);
	cout << "����";
	SetColor(ROSERED, LIGHTGREY);
	SetPosition(66, 17);
	cout << "����";
	SetColor(SKYBLUE, LIGHTGREY);
	SetPosition(80, 17);
	cout << "����";
	SetColor(DARKBLUE, LIGHTGREY);
	SetPosition(35, 24);
	cout << "J & L�����ѡ�����ר����ɫ��!!!!!!!!!";
	SetPosition(8, 12);
	cout << "P L A Y E R 1��";

	char ch;
	color1 = 1;
	bool flag = false;
	while ((ch = _getch()))
	{
		switch (ch)
		{
		case 'j'://��
			if (color1 > 1)
			{
				switch (color1)
				{
				case 2:
					SetColor(PURPLE, LIGHTYELLOW);
					SetPosition(24, 17);
					cout << "����";

					SetColor(DARKYELLOW, LIGHTGREY);
					SetPosition(38, 17);
					cout << "����";
					--color1;
					break;
				case 3:
					SetColor(DARKYELLOW, LIGHTYELLOW);
					SetPosition(38, 17);
					cout << "����";

					SetColor(MINT, LIGHTGREY);
					SetPosition(52, 17);
					cout << "����";
					--color1;
					break;
				case 4:
					SetColor(MINT, LIGHTYELLOW);
					SetPosition(52, 17);
					cout << "����";

					SetColor(ROSERED, LIGHTGREY);
					SetPosition(66, 17);
					cout << "����";
					--color1;
					break;
				case 5:
					SetColor(ROSERED, LIGHTYELLOW);
					SetPosition(66, 17);
					cout << "����";

					SetColor(SKYBLUE, LIGHTGREY);
					SetPosition(80, 17);
					cout << "����";
					--color1;
					break;

				}
			}
			break;
		case 'l'://��
			if (color1 < 5)
			{
				switch (color1)
				{
				case 1:
					SetColor(DARKYELLOW, LIGHTYELLOW);
					SetPosition(38, 17);
					cout << "����";

					SetColor(PURPLE, LIGHTGREY);
					SetPosition(24, 17);
					cout << "����";
					++color1;
					break;
				case 2:
					SetColor(MINT, LIGHTYELLOW);
					SetPosition(52, 17);
					cout << "����";

					SetColor(DARKYELLOW, LIGHTGREY);
					SetPosition(38, 17);
					cout << "����";
					++color1;
					break;
				case 3:
					SetColor(ROSERED, LIGHTYELLOW);
					SetPosition(66, 17);
					cout << "����";

					SetColor(MINT, LIGHTGREY);
					SetPosition(52, 17);
					cout << "����";
					++color1;
					break;
				case 4:
					SetColor(SKYBLUE, LIGHTYELLOW);
					SetPosition(80, 17);
					cout << "����";

					SetColor(ROSERED, LIGHTGREY);
					SetPosition(66, 17);
					cout << "����";
					++color1;
					break;
				}
			}
			break;
		case 13://Enter
			flag = true;
			break;
		default:
			break;
		}
		if (flag)
		{
			break;
		}
	}
}
void Controller::Color2()
{
	SetPosition(24, 17);
	cout << "      ";
	SetPosition(38, 17);
	cout << "      ";
	SetPosition(52, 17);
	cout << "      ";
	SetPosition(66, 17);
	cout << "      ";
	SetPosition(80, 17);
	cout << "      ";
	SetPosition(35, 24);
	cout << "                                       ";
	SetPosition(8, 12);
	cout << "               ";
	/*��ʼ�������ͼѡ��*/
	SetColor(PURPLE, LIGHTYELLOW);
	SetPosition(24, 17);
	cout << "����";
	SetColor(DARKYELLOW, LIGHTGREY);
	SetPosition(38, 17);
	cout << "����";
	SetColor(MINT, LIGHTGREY);
	SetPosition(52, 17);
	cout << "����";
	SetColor(ROSERED, LIGHTGREY);
	SetPosition(66, 17);
	cout << "����";
	SetColor(SKYBLUE, LIGHTGREY);
	SetPosition(80, 17);
	cout << "����";
	SetColor(DARKBLUE, LIGHTGREY);
	SetPosition(35, 24);
	cout << "A & D�����ѡ�����ר����ɫ��!!!!!!!!!";
	SetPosition(8, 12);
	cout << "P L A Y E R 2��";
	char ch;
	color2 = 1;
	bool flag = false;
	while ((ch = _getch()))
	{
		switch (ch)
		{
		case 'a'://��
			if (color2 > 1)
			{
				switch (color2)
				{
				case 2:
					SetColor(PURPLE, LIGHTYELLOW);
					SetPosition(24, 17);
					cout << "����";

					SetColor(DARKYELLOW, LIGHTGREY);
					SetPosition(38, 17);
					cout << "����";
					--color2;
					break;
				case 3:
					SetColor(DARKYELLOW, LIGHTYELLOW);
					SetPosition(38, 17);
					cout << "����";

					SetColor(MINT, LIGHTGREY);
					SetPosition(52, 17);
					cout << "����";
					--color2;
					break;
				case 4:
					SetColor(MINT, LIGHTYELLOW);
					SetPosition(52, 17);
					cout << "����";

					SetColor(ROSERED, LIGHTGREY);
					SetPosition(66, 17);
					cout << "����";
					--color2;
					break;
				case 5:
					SetColor(ROSERED, LIGHTYELLOW);
					SetPosition(66, 17);
					cout << "����";

					SetColor(SKYBLUE, LIGHTGREY);
					SetPosition(80, 17);
					cout << "����";
					--color2;
					break;

				}
			}
			break;
		case 'd'://��
			if (color2 < 5)
			{
				switch (color2)
				{
				case 1:
					SetColor(DARKYELLOW, LIGHTYELLOW);
					SetPosition(38, 17);
					cout << "����";

					SetColor(PURPLE, LIGHTGREY);
					SetPosition(24, 17);
					cout << "����";
					++color2;
					break;
				case 2:
					SetColor(MINT, LIGHTYELLOW);
					SetPosition(52, 17);
					cout << "����";

					SetColor(DARKYELLOW, LIGHTGREY);
					SetPosition(38, 17);
					cout << "����";
					++color2;
					break;
				case 3:
					SetColor(ROSERED, LIGHTYELLOW);
					SetPosition(66, 17);
					cout << "����";

					SetColor(MINT, LIGHTGREY);
					SetPosition(52, 17);
					cout << "����";
					++color2;
					break;
				case 4:
					SetColor(SKYBLUE, LIGHTYELLOW);
					SetPosition(80, 17);
					cout << "����";

					SetColor(ROSERED, LIGHTGREY);
					SetPosition(66, 17);
					cout << "����";
					++color2;
					break;
				}
			}
			break;
		case 13://Enter
			flag = true;
			break;
		default:
			break;
		}
		if (flag)
		{
			break;
		}
	}
}
void Controller::DrawGame()
{
	system("cls");//����
	system("color FF");
	Map* initialmap = new Map;
	Initialinterface* start = new Initialinterface;
	SetFont(25);
	/*��ͼ��ѡ��������д���ĸ������ټӻ��߼����Ӽ������getch�������Լ�һ�¾Ϳ���ʵ����*/
	switch (key)
	{
	case 1:
		start->Print();
		PlaySound(TEXT("9882.wav"), NULL, SND_FILENAME | SND_ASYNC);
		Sleep(1200);
		system("cls");
		PlaySound(TEXT("������� (���Ȥ� �ޤ���) - �ɥ��Х���������� (��������Chorogons).wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
		initialmap->IniMap1();
		delete initialmap;
		break;
	case 2:
		start->Print1();
		PlaySound(TEXT("9882.wav"), NULL, SND_FILENAME | SND_ASYNC);
		Sleep(1200);
		system("cls");
		PlaySound(TEXT("������� (���Ȥ� �ޤ���) - �ɥ��Х���������� (��������Chorogons).wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
		initialmap->IniMap2();
		delete initialmap;
		break;
	case 3:
		start->Print2();
		PlaySound(TEXT("9882.wav"), NULL, SND_FILENAME | SND_ASYNC);
		Sleep(1200);
		system("cls");
		PlaySound(TEXT("������� (���Ȥ� �ޤ���) - �ɥ��Х���������� (��������Chorogons).wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
		initialmap->IniMap3();
		delete initialmap;
		break;
	}
}
void BombManThread_1(Bombman*& bombman1, Bombman*& bombman2)
{
	while (1)
	{
		if (ifGameEnded == 1)
			return;
		else
		{
			if (flag == 1)
			{
				unique_lock<mutex>locker(mtxPlayers);
				bombman2->Changedirection2();
				locker.unlock();
				Sleep(20);
				locker.lock();
				bombman1->Changedirection1();
				locker.unlock();
				flag = 0;
			}
		}
	}
}
void BombManThread_3(Bombman*& bombman1, Bombman*& bombman2)
{
	while (1)
	{
		if (ifGameEnded == 1)
			return;
		else
		{
			if (bombman2->getKey())
			{
				unique_lock<mutex>locker(mtxPlayers);
				if (color2 == 1)
				{
					SetColor(PURPLE, WHITE);
				}
				else if (color2 == 2)
				{
					SetColor(DARKYELLOW, WHITE);
				}
				else if (color2 == 3)
				{
					SetColor(MINT, WHITE);
				}
				else if (color2 == 4)
				{
					SetColor(ROSERED, WHITE);
				}
				else if (color2 == 5)
				{
					SetColor(SKYBLUE, WHITE);
				}
				bombman2->Action(key, 2);
				bombman2->setKey(0);
			}
			Sleep(25);
			if (bombman1->getKey())
			{
				unique_lock<mutex>locker(mtxPlayers);
				if (color1 == 1)
				{
					SetColor(PURPLE, WHITE);
				}
				else if (color1 == 2)
				{
					SetColor(DARKYELLOW, WHITE);
				}
				else if (color1 == 3)
				{
					SetColor(MINT, WHITE);
				}
				else if (color1 == 4)
				{
					SetColor(ROSERED, WHITE);
				}
				else if (color1 == 5)
				{
					SetColor(SKYBLUE, WHITE);
				}
				bombman1->Action(key, 1);
				bombman1->setKey(0);

			}
			flag = 1;
			cv.notify_one();
			Sleep(25);
		}


	}
}
void BombCreating(Bombman*& bombman1, Bombman*& bombman2)
{
	while (1)
	{
		if (ifGameEnded == 1)
			return;
		else
		{
			bombman1->BombCreate();
			bombman2->BombCreate();
			cv.notify_one();
			Sleep(15 * 1000);
		}

	}
}
//����
void showPlayerStatus(Bombman*& bombman1, Bombman*& bombman2)
{
	while (1)
	{
		if (ifGameEnded == 1)
			return;
		else
		{
			unique_lock<mutex>locker(mtxPlayers);
			bombman1->showPlayerStatus(key, 1);
			locker.unlock();
			Sleep(20);
			locker.lock();
			bombman2->showPlayerStatus(key, 2);
			cv.wait(locker);
		}
	}

}
//��Ϸ�߳�
bool Controller::PlayGame()//��Ϸ�߼���ʼ���˺���Ϸ���߼�����ô���̶߳�һ���ٲ����ⲿ��
{
	if (key == 1)
	{
		Bombman* bombman1 = new CherryBombman;
		Bombman* bombman2 = new CherryBombman;
		bombman1->Initialbombman1();
		bombman2->Initialbombman2();
		thread threadShowStatus(showPlayerStatus, ref(bombman1), ref(bombman2));
		thread threadbombman1(BombManThread_1, ref(bombman1), ref(bombman2));
		Sleep(10);
		thread threadbombman3(BombManThread_3, ref(bombman1), ref(bombman2));
		Sleep(6 * 1000);
		thread threadBomb(BombCreating, ref(bombman1), ref(bombman2));
		threadbombman1.join();
		threadbombman3.join();
		PlaySound(TEXT("���� - ��Ȫӳ��.wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
		unique_lock<mutex> locker(mtxPlayers);
		if (Bombflag == 1)
		{
			SetPosition(30 * 2, 21);
			cout << "          ";
			SetPosition(30 * 2, 21);
			cout << "THE WINNER";
			SetPosition(32 * 2, 23);
			cout << "  ";
			SetPosition(32 * 2, 23);
			cout << "IS";
			SetPosition(30 * 2, 25);
			cout << "           ";
			SetPosition(30 * 2, 25);
			cout << "PLAYER_2!!!";
		}
		else if (Bombflag == 2)
		{
			SetPosition(30 * 2, 21);
			cout << "          ";
			SetPosition(30 * 2, 21);
			cout << "THE WINNER";
			SetPosition(32 * 2, 23);
			cout << "  ";
			SetPosition(32 * 2, 23);
			cout << "IS";
			SetPosition(30 * 2, 25);
			cout << "           ";
			SetPosition(30 * 2, 25);
			cout << "PLAYER_1!!!";
		}
		Sleep(5 * 1000);
		threadBomb.join();
		threadShowStatus.join();
		delete bombman1;
		delete bombman2;
		if (GameOver())
			return true;
		else
			return false;
	}
	else if (key == 2)
	{
		Bombman* bombman1 = new PeachBombman;
		Bombman* bombman2 = new PeachBombman;
		bombman1->Initialbombman1();
		bombman2->Initialbombman2();
		thread threadShowStatus(showPlayerStatus, ref(bombman1), ref(bombman2));
		thread threadbombman1(BombManThread_1, ref(bombman1), ref(bombman2));
		Sleep(10);
		thread threadbombman3(BombManThread_3, ref(bombman1), ref(bombman2));
		Sleep(6 * 1000);
		thread threadBomb(BombCreating, ref(bombman1), ref(bombman2));
		threadbombman1.join();
		threadbombman3.join();
		PlaySound(TEXT("���� - ��Ȫӳ��.wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
		unique_lock<mutex> locker(mtxPlayers);
		if (Bombflag == 1)
		{
			SetPosition(30 * 2, 21);
			cout << "          ";
			SetPosition(30 * 2, 21);
			cout << "THE WINNER";
			SetPosition(32 * 2, 23);
			cout << "  ";
			SetPosition(32 * 2, 23);
			cout << "IS";
			SetPosition(30 * 2, 25);
			cout << "           ";
			SetPosition(30 * 2, 25);
			cout << "PLAYER_2!!!";
		}
		else if (Bombflag == 2)
		{
			SetPosition(30 * 2, 21);
			cout << "          ";
			SetPosition(30 * 2, 21);
			cout << "THE WINNER";
			SetPosition(32 * 2, 23);
			cout << "  ";
			SetPosition(32 * 2, 23);
			cout << "IS";
			SetPosition(30 * 2, 25);
			cout << "           ";
			SetPosition(30 * 2, 25);
			cout << "PLAYER_1!!!";
		}
		threadBomb.join();
		threadShowStatus.join();
		delete bombman1;
		delete bombman2;
		if (GameOver())
			return true;
		else
			return false;
	}
	else if (key == 3)
	{
		Bombman* bombman1 = new StrawBerryBombman;
		Bombman* bombman2 = new StrawBerryBombman;
		bombman1->Initialbombman1();
		bombman2->Initialbombman2();
		thread threadShowStatus(showPlayerStatus, ref(bombman1), ref(bombman2));
		thread threadbombman1(BombManThread_1, ref(bombman1), ref(bombman2));
		Sleep(10);
		thread threadbombman3(BombManThread_3, ref(bombman1), ref(bombman2));
		Sleep(6 * 1000);
		thread threadBomb(BombCreating, ref(bombman1), ref(bombman2));
		threadbombman1.join();
		threadbombman3.join();
		PlaySound(TEXT("���� - ��Ȫӳ��.wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
		unique_lock<mutex> locker(mtxPlayers);
		if (Bombflag == 1)
		{
			SetPosition(30 * 2, 21);
			cout << "          ";
			SetPosition(30 * 2, 21);
			cout << "THE WINNER";
			SetPosition(32 * 2, 23);
			cout << "  ";
			SetPosition(32 * 2, 23);
			cout << "IS";
			SetPosition(30 * 2, 25);
			cout << "           ";
			SetPosition(30 * 2, 25);
			cout << "PLAYER_2!!!";
		}
		else if (Bombflag == 2)
		{
			SetPosition(30 * 2, 21);
			cout << "          ";
			SetPosition(30 * 2, 21);
			cout << "THE WINNER";
			SetPosition(32 * 2, 23);
			cout << "  ";
			SetPosition(32 * 2, 23);
			cout << "IS";
			SetPosition(30 * 2, 25);
			cout << "           ";
			SetPosition(30 * 2, 25);
			cout << "PLAYER_1!!!";
		}
		threadBomb.join();
		threadShowStatus.join();
		delete bombman1;
		delete bombman2;
		if (GameOver())
			return true;
		else
			return false;
	}

}
void Controller::Game()//��Ϸһ��ѭ��
{
	Start();
	Color1();
	Color2();
	while (true)
	{
		Select();
		DrawGame();
		bool tmp = PlayGame();
		if (tmp)
		{
			ifGameEnded = 0;
			system("cls");
			PlaySound(TEXT("���x �� (�錄�ʤ� ������) - Relax��������`�� (Relax������).wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
			for (int i = 0; i <= 21; i++)
				for (int j = 0; j <= 21; j++)
					Attr[i][j] = 0;
			continue;
		}
		else
		{
			SetFont(20);
			system("cls");
			system("color F7");
			Initialinterface* start = new Initialinterface();
			start->PrintStart();
			SetColor(BLACK, WHITE);
			SetPosition(43, 15);
			cout << "��ӭ�´ι���!!!!!";
			SetPosition(43, 25);
			return;
		}
	}
}
bool Controller::GameOver()//�������������Ҫ����ȥ����������Ϸ/����лл��Ҫȥѧϰ��������������ѡ�񳹵׽�����Ϸ
{
	/*��Ϸ��������*/
	system("cls");
	system("color F7");
	Initialinterface* start = new Initialinterface();
	start->PrintStart();
	SetColor(BLACK, WHITE);
	SetPosition(43, 10);
	cout << "G A M E  O V E R!!!!!��";
	SetPosition(42, 13);
	cout << "���·���ѡ�񣬻س�ȷ��";
	SetPosition(42, 17);
	SetColor(BLACK, LIGHTYELLOW);
	cout << "Ҭ˿��̫������!����һ�֣�";
	SetPosition(42, 25);
	SetColor(BLACK, WHITE);
	cout << "Ī�������һ�����ѧϰ��!";

	/*ѡ��*/
	int ch;
	int key = 1;
	bool flag = false;
	while ((ch = _getch()))
	{
		switch (ch)
		{
		case 72://��
			if (key > 1)
			{
				SetColor(BLACK, LIGHTYELLOW);
				SetPosition(44, 17);
				cout << "Ҭ˿��̫������!����һ�֣�";
				SetColor(BLACK, WHITE);
				SetPosition(44, 25);
				cout << "Ī�������һ�����ѧϰ��!";
				--key;

			}
			break;
		case 80://��
			if (key < 2)
			{
				SetColor(BLACK, LIGHTYELLOW);
				SetPosition(44, 25);
				cout << "Ī�������һ�����ѧϰ��!";
				SetColor(BLACK, WHITE);
				SetPosition(44, 17);
				cout << "Ҭ˿��̫������!����һ�֣�";
				++key;

			}
			break;
		case 13://Enter
			flag = true;
			break;
		default:
			break;
		}
		if (flag)
		{
			break;
		}
	}
	switch (key)
	{
	case 1:
		return true;
	case 2:
		return false;
	}
}
