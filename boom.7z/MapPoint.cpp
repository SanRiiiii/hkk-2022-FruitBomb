#include"MapPoint.h"
MapPoint::MapPoint(const int x, const int y, int attr1, int attr2)
	:m_attr1(attr1), m_attr2(attr2)
{
	Printpoint(x, y);
}
int MapPoint::GetAttr1()const
{
	return m_attr1;
}
int MapPoint::GetAttr2()const
{
	return m_attr2;
}
void MapPoint::SetAttr1(int a1)
{
	m_attr1 = a1;
}
void MapPoint::SetAttr2(int a2)
{
	m_attr1 = a2;
}
bool MapPoint::Judge(MapPoint p)
{
	if (p.m_attr1 == 1)
		return true;
	else return false;
}