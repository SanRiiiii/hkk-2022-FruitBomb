#include "Initialinterface.h"
#include<Windows.h>
#include"SetWindows.h"
#include<cstdlib>
#include<ctime>
#include<iostream>
using namespace std;

void Initialinterface::Print()
{
	while (endstart.back().GetX() < 30)
	{
        CleanCherry();
		PrintCherry();
		Sleep(100);
	}

}
void Initialinterface::Print1()
{
	while (endstart.back().GetX() < 30)
	{
		CleanPeach();
		PrintPeach();
		Sleep(100);
	}

}
void Initialinterface::Print2()
{
	while (endstart.back().GetX() < 30)
	{
		CleanStrawberry();
		PrintStrawberry();
		Sleep(100);
	}

}
void Initialinterface::Action()
{
	Print();
}
//ͼCherry
void Initialinterface::CherryRed()
{
	
	cherryred.emplace_back(Printpoint(-2, 15));
	cherryred.emplace_back(Printpoint(-2, 16));
	cherryred.emplace_back(Printpoint(-4, 14));
	cherryred.emplace_back(Printpoint(-4, 15));
	cherryred.emplace_back(Printpoint(-4, 16));
	cherryred.emplace_back(Printpoint(-4, 17));
	cherryred.emplace_back(Printpoint(-6, 14));
	cherryred.emplace_back(Printpoint(-6, 15));
	cherryred.emplace_back(Printpoint(-6, 16));
	cherryred.emplace_back(Printpoint(-6, 17));
	cherryred.emplace_back(Printpoint(-8, 15));
	cherryred.emplace_back(Printpoint(-8, 16));
	cherryred.emplace_back(Printpoint(-12, 15));
	cherryred.emplace_back(Printpoint(-12, 16));
	cherryred.emplace_back(Printpoint(-14, 14));
	cherryred.emplace_back(Printpoint(-14, 15));
	cherryred.emplace_back(Printpoint(-14, 16));
	cherryred.emplace_back(Printpoint(-14, 17));
	cherryred.emplace_back(Printpoint(-16, 14));
	cherryred.emplace_back(Printpoint(-16, 15));
	cherryred.emplace_back(Printpoint(-16, 16));
	cherryred.emplace_back(Printpoint(-16, 17));
	cherryred.emplace_back(Printpoint(-18, 15));
	cherryred.emplace_back(Printpoint(-18, 16));
}
void Initialinterface::CherryGreen()
{
	
	cherrygreen.emplace_back(Printpoint(-6, 13));
	cherrygreen.emplace_back(Printpoint(-8, 12));
	cherrygreen.emplace_back(Printpoint(-8, 10));
	cherrygreen.emplace_back(Printpoint(-10, 13));
	cherrygreen.emplace_back(Printpoint(-10, 11));
	cherrygreen.emplace_back(Printpoint(-12, 10));
	cherrygreen.emplace_back(Printpoint(-12, 12));
	cherrygreen.emplace_back(Printpoint(-14, 13));
}
void Initialinterface::CherryEnd()
{
	endstart.emplace_back(Printpoint(-50, 16));
}
void Initialinterface::PrintCherry()
{
	SetColor(DARKRED, WHITE);
	for (auto& Printpoint : cherryred)
	{
		if (Printpoint.GetX() >= 0)
			Printpoint.Printrectangle();
	}
	SetColor(DARKGREEN, WHITE);
	for (auto& Printpoint : cherrygreen)
	{
		if (Printpoint.GetX() >= 0)
			Printpoint.Printrectangle();
	}
}
void Initialinterface::CleanCherry()
{
	
	for (auto& Printpoint : cherryred)
	{
		SetColor(WHITE, WHITE);
		if (Printpoint.GetX() >= 0)
			Printpoint.Clear();
		Printpoint.Changeposition(Printpoint.GetX() + 1, Printpoint.GetY());
	}
	for (auto& Printpoint : cherrygreen)
	{
		SetColor(WHITE, WHITE);
		if (Printpoint.GetX() >= 0)
			Printpoint.Clear();

		Printpoint.Changeposition(Printpoint.GetX() + 1, Printpoint.GetY());
	}
	for (auto& Printpoint : endstart)
	{
		Printpoint.Changeposition(Printpoint.GetX() + 1, Printpoint.GetY());
	}


}
//ͼPeach
void Initialinterface::PeachPink()
{
	
	peachpink.emplace_back(Printpoint(-34,9));
	peachpink.emplace_back(Printpoint(-36,9));
	peachpink.emplace_back(Printpoint(-32,10));
	peachpink.emplace_back(Printpoint(-34, 10));
	peachpink.emplace_back(Printpoint(-36, 10));
	peachpink.emplace_back(Printpoint(-38, 10));
	peachpink.emplace_back(Printpoint(-30, 11));
	peachpink.emplace_back(Printpoint(-32, 11));
	peachpink.emplace_back(Printpoint(-34, 11));
	peachpink.emplace_back(Printpoint(-36, 11));
	peachpink.emplace_back(Printpoint(-38, 11));
	peachpink.emplace_back(Printpoint(-40, 11));
	for (int j = 12; j < 15; j++)
	{
		for (int i = -28; i > -44;)
		{
			peachpink.emplace_back(Printpoint(i, j));
			i -= 2;
		}
	}
	peachpink.emplace_back(Printpoint(-30, 15));
	peachpink.emplace_back(Printpoint(-32, 15));
	peachpink.emplace_back(Printpoint(-34, 15));
	peachpink.emplace_back(Printpoint(-36, 15));
	peachpink.emplace_back(Printpoint(-38, 15));
	peachpink.emplace_back(Printpoint(-40, 15));
	peachpink.emplace_back(Printpoint(-30, 16));
	peachpink.emplace_back(Printpoint(-32, 16));
	peachpink.emplace_back(Printpoint(-34, 16));
	peachpink.emplace_back(Printpoint(-36, 16));
	peachpink.emplace_back(Printpoint(-38, 16));
	

}
void Initialinterface::PeachGreen()
{
	peachgreen.emplace_back(Printpoint(-28, 16));
	peachgreen.emplace_back(Printpoint(-40, 16));
	peachgreen.emplace_back(Printpoint(-42, 16));
	peachgreen.emplace_back(Printpoint(-30, 17));
	peachgreen.emplace_back(Printpoint(-32, 17));
	peachgreen.emplace_back(Printpoint(-34, 17));
}
void Initialinterface::PrintPeach()
{
	SetColor(LIGHTRED, WHITE);
	for (auto& Printpoint : peachpink)
	{
		
		if (Printpoint.GetX() >= 0)
			Printpoint.Printrectangle();
	}
	SetColor(DARKGREEN, WHITE);
	for (auto& Printpoint : peachgreen)
	{
		
		if (Printpoint.GetX() >= 0)
			Printpoint.Printrectangle();
	}
}
void Initialinterface::CleanPeach()
{
	
	for (auto& Printpoint : peachpink)
	{
		SetColor(WHITE, WHITE);
		if (Printpoint.GetX() >= 0)
			Printpoint.Clear();
		Printpoint.Changeposition(Printpoint.GetX() + 1, Printpoint.GetY());
	}
	for (auto& Printpoint : peachgreen)
	{
		SetColor(WHITE, WHITE);
		if (Printpoint.GetX() >= 0)
			Printpoint.Clear();
		Printpoint.Changeposition(Printpoint.GetX() + 1, Printpoint.GetY());
	}
	for (auto& Printpoint : endstart)
	{
		Printpoint.Changeposition(Printpoint.GetX() + 1, Printpoint.GetY());
	}
}
//ͼStrawberry
void Initialinterface::StrawberryRed()
{
	for (int i = 30; i < 46;)
	{
		strawberryred.emplace_back(Printpoint(-i, 13));
		strawberryred.emplace_back(Printpoint(-i, 15));
		i += 2;
	}
	for (int i = 34; i < 42;)
	{
		strawberryred.emplace_back(Printpoint(-i, 17));
		i += 2;
	}
	strawberryred.emplace_back(Printpoint(-34, 10));
	strawberryred.emplace_back(Printpoint(-40, 10));
	strawberryred.emplace_back(Printpoint(-42, 11));
	strawberryred.emplace_back(Printpoint(-38, 11));
	strawberryred.emplace_back(Printpoint(-36, 11));
	strawberryred.emplace_back(Printpoint(-32, 11));
	strawberryred.emplace_back(Printpoint(-44, 12));
	strawberryred.emplace_back(Printpoint(-36, 12));
	strawberryred.emplace_back(Printpoint(-42, 14));
	strawberryred.emplace_back(Printpoint(-38, 14));
	strawberryred.emplace_back(Printpoint(-34, 14));
	strawberryred.emplace_back(Printpoint(-30, 14));
	strawberryred.emplace_back(Printpoint(-40, 16));
	strawberryred.emplace_back(Printpoint(-36, 16));
	strawberryred.emplace_back(Printpoint(-34, 16));
	strawberryred.emplace_back(Printpoint(-36, 18));

	
}
void Initialinterface::StrawberryGreen()
{
	for (int i = 34; i < 42;)
	{
		strawberrygreen.emplace_back(Printpoint(-i, 9));
		i += 2;
	}
	strawberrygreen.emplace_back(Printpoint(-46, 12));
	strawberrygreen.emplace_back(Printpoint(-44, 11));
	strawberrygreen.emplace_back(Printpoint(-42, 10));
	strawberrygreen.emplace_back(Printpoint(-38, 8));
	strawberrygreen.emplace_back(Printpoint(-36, 7));
	strawberrygreen.emplace_back(Printpoint(-38, 10));
	strawberrygreen.emplace_back(Printpoint(-36, 10));
	strawberrygreen.emplace_back(Printpoint(-32, 10));
	strawberrygreen.emplace_back(Printpoint(-30, 11));
	strawberrygreen.emplace_back(Printpoint(-28, 12));
	strawberrygreen.emplace_back(Printpoint(-32, 12));
	strawberrygreen.emplace_back(Printpoint(-40, 12));
	strawberrygreen.emplace_back(Printpoint(-34, 11));
	strawberrygreen.emplace_back(Printpoint(-40, 11));


}
void Initialinterface::StrawberryWhite()
{
	strawberrywhite.emplace_back(Printpoint(-42, 12));
	strawberrywhite.emplace_back(Printpoint(-38, 12));
	strawberrywhite.emplace_back(Printpoint(-34, 12));
	strawberrywhite.emplace_back(Printpoint(-30, 12));
	strawberrywhite.emplace_back(Printpoint(-44, 14));
	strawberrywhite.emplace_back(Printpoint(-40, 14));
	strawberrywhite.emplace_back(Printpoint(-36, 14));
	strawberrywhite.emplace_back(Printpoint(-32, 14));
	strawberrywhite.emplace_back(Printpoint(-42, 16));
	strawberrywhite.emplace_back(Printpoint(-38, 16));
	strawberrywhite.emplace_back(Printpoint(-32, 16));
	strawberrywhite.emplace_back(Printpoint(-38, 18));
}
void Initialinterface::PrintStrawberry()
{
    SetColor(LIGHTRED, WHITE);
	for (auto& Printpoint : strawberryred)
	{
		
		if (Printpoint.GetX() >= 0)
			Printpoint.Printrectangle();
	}
	SetColor(DARKGREEN, WHITE);
	for (auto& Printpoint : strawberrygreen)
	{
		
		if (Printpoint.GetX() >= 0)
			Printpoint.Printrectangle();
	}
	SetColor(DARKRED, WHITE);
	for (auto& Printpoint : strawberrywhite)
	{
		
		if (Printpoint.GetX() >= 0)
			Printpoint.Printrectangle();
	}
}
void Initialinterface::CleanStrawberry()
{
	SetColor(WHITE, WHITE);
	for (auto& Printpoint : strawberryred)
	{
		
		if (Printpoint.GetX() >= 0)
			Printpoint.Clear();
		Printpoint.Changeposition(Printpoint.GetX() + 1, Printpoint.GetY());
	}
	SetColor(WHITE, WHITE);
	for (auto& Printpoint : strawberrygreen)
	{
		
		if (Printpoint.GetX() >= 0)
			Printpoint.Clear();
		Printpoint.Changeposition(Printpoint.GetX() + 1, Printpoint.GetY());
	}
	SetColor(WHITE, WHITE);
	for (auto& Printpoint : strawberrywhite)
	{
		
		if (Printpoint.GetX() >= 0)
			Printpoint.Clear();
		Printpoint.Changeposition(Printpoint.GetX() + 1, Printpoint.GetY());
	}
	for (auto& Printpoint : endstart)
	{
		Printpoint.Changeposition(Printpoint.GetX() + 1, Printpoint.GetY());
	}
}

//��FRUITBOMB
void Initialinterface::Text1()
{
	
	//DARKRED�������Ͻ�
	textboom1.emplace_back(Printpoint(2, 11));
	textboom1.emplace_back(Printpoint(2, 12));
	textboom1.emplace_back(Printpoint(4, 11));
	textboom1.emplace_back(Printpoint(2, 13));
	textboom1.emplace_back(Printpoint(6, 11));
	textboom1.emplace_back(Printpoint(8, 11));
	textboom1.emplace_back(Printpoint(10, 11));
	textboom1.emplace_back(Printpoint(2, 14));
	textboom1.emplace_back(Printpoint(14, 11));
	textboom1.emplace_back(Printpoint(16, 11));
    textboom1.emplace_back(Printpoint(14, 12));
	textboom1.emplace_back(Printpoint(18, 11));
	textboom1.emplace_back(Printpoint(14, 13));
	textboom1.emplace_back(Printpoint(20, 11));
	textboom1.emplace_back(Printpoint(22, 11));
	textboom1.emplace_back(Printpoint(22, 12));
	textboom1.emplace_back(Printpoint(26, 11));
	textboom1.emplace_back(Printpoint(34, 11));
	textboom1.emplace_back(Printpoint(2, 15));
	textboom1.emplace_back(Printpoint(4, 15));
	textboom1.emplace_back(Printpoint(6, 15));
	textboom1.emplace_back(Printpoint(8, 15));
	textboom1.emplace_back(Printpoint(10, 15));
	textboom1.emplace_back(Printpoint(14, 14));
	textboom1.emplace_back(Printpoint(14, 15));
	textboom1.emplace_back(Printpoint(2, 11));
	textboom1.emplace_back(Printpoint(22, 13));
	textboom1.emplace_back(Printpoint(22, 14));
	textboom1.emplace_back(Printpoint(26, 12));
	textboom1.emplace_back(Printpoint(26, 13));
	textboom1.emplace_back(Printpoint(34, 12));
	textboom1.emplace_back(Printpoint(38, 11));
	textboom1.emplace_back(Printpoint(40, 11));
	textboom1.emplace_back(Printpoint(42, 11));
	textboom1.emplace_back(Printpoint(44, 11));
	textboom1.emplace_back(Printpoint(2, 11));
	textboom1.emplace_back(Printpoint(46, 11));
	textboom1.emplace_back(Printpoint(50, 11));
	textboom1.emplace_back(Printpoint(52, 11));
	textboom1.emplace_back(Printpoint(54, 11));
	textboom1.emplace_back(Printpoint(56, 11));
	textboom1.emplace_back(Printpoint(2, 16));
	textboom1.emplace_back(Printpoint(14, 16));
	textboom1.emplace_back(Printpoint(16, 15));
	textboom1.emplace_back(Printpoint(18, 15));
	textboom1.emplace_back(Printpoint(20, 15));
	textboom1.emplace_back(Printpoint(26, 14));
	textboom1.emplace_back(Printpoint(34, 13));
	textboom1.emplace_back(Printpoint(42, 12));
	textboom1.emplace_back(Printpoint(42, 13));
	textboom1.emplace_back(Printpoint(58, 11));
	textboom1.emplace_back(Printpoint(62, 11));
    textboom1.emplace_back(Printpoint(54, 12));
	textboom1.emplace_back(Printpoint(2, 17));
}
void Initialinterface::Text2()
{
	
	textboom.emplace_back(Printpoint(2, 18));
	textboom.emplace_back(Printpoint(2, 19));
	textboom.emplace_back(Printpoint(14, 17));
	textboom.emplace_back(Printpoint(16, 16));
	textboom.emplace_back(Printpoint(14, 18));
	textboom.emplace_back(Printpoint(18, 17));
	textboom.emplace_back(Printpoint(26, 15));
	textboom.emplace_back(Printpoint(34, 14));
	textboom.emplace_back(Printpoint(26, 16));
	textboom.emplace_back(Printpoint(34, 15));
	textboom.emplace_back(Printpoint(26, 17));
	textboom.emplace_back(Printpoint(34, 16));
	textboom.emplace_back(Printpoint(42, 14));
	textboom.emplace_back(Printpoint(42, 15));
	textboom.emplace_back(Printpoint(54, 13));
	textboom.emplace_back(Printpoint(54, 14));
	textboom.emplace_back(Printpoint(62, 12));
	textboom.emplace_back(Printpoint(62, 13));
	textboom.emplace_back(Printpoint(64, 11));
	textboom.emplace_back(Printpoint(66, 11));
	textboom.emplace_back(Printpoint(68, 11));
	textboom.emplace_back(Printpoint(70, 12));
	textboom.emplace_back(Printpoint(74, 11));
	textboom.emplace_back(Printpoint(76, 11));
	textboom.emplace_back(Printpoint(78, 11));
	textboom.emplace_back(Printpoint(70, 13));
	textboom.emplace_back(Printpoint(74, 12));
	textboom.emplace_back(Printpoint(80, 11));
	textboom.emplace_back(Printpoint(14, 19));
	textboom.emplace_back(Printpoint(20, 18));
	textboom.emplace_back(Printpoint(22, 19));
	textboom.emplace_back(Printpoint(26, 18));
	textboom.emplace_back(Printpoint(34, 17));
	textboom.emplace_back(Printpoint(42, 16));
	textboom.emplace_back(Printpoint(54, 15));
	textboom.emplace_back(Printpoint(62, 14));
	textboom.emplace_back(Printpoint(82, 11));
	textboom.emplace_back(Printpoint(87, 11));
	textboom.emplace_back(Printpoint(82, 12));
	textboom.emplace_back(Printpoint(89, 11));
	textboom.emplace_back(Printpoint(91, 11));
	textboom.emplace_back(Printpoint(96, 11));
	textboom.emplace_back(Printpoint(98, 11));
	textboom.emplace_back(Printpoint(100, 11));
	textboom.emplace_back(Printpoint(26, 19));
	textboom.emplace_back(Printpoint(28, 19));
	textboom.emplace_back(Printpoint(30, 19));
	textboom.emplace_back(Printpoint(34, 18));
	textboom.emplace_back(Printpoint(32, 19));
	textboom.emplace_back(Printpoint(42, 17));
	textboom.emplace_back(Printpoint(54, 16));
	textboom.emplace_back(Printpoint(62, 15));
	textboom.emplace_back(Printpoint(64, 15));
	textboom.emplace_back(Printpoint(66, 15));
	textboom.emplace_back(Printpoint(70, 14));
	textboom.emplace_back(Printpoint(74, 13));
	textboom.emplace_back(Printpoint(74, 14));
	textboom.emplace_back(Printpoint(82, 13));
	textboom.emplace_back(Printpoint(87, 12));
	textboom.emplace_back(Printpoint(87, 13));
	textboom.emplace_back(Printpoint(91, 12));
	textboom.emplace_back(Printpoint(96, 11));
	textboom.emplace_back(Printpoint(105, 11));
	textboom.emplace_back(Printpoint(107, 11));
	textboom.emplace_back(Printpoint(34, 19));
	textboom.emplace_back(Printpoint(38, 19));
	textboom.emplace_back(Printpoint(40, 19));
	textboom.emplace_back(Printpoint(42, 18)); 
	textboom.emplace_back(Printpoint(42, 19));
	textboom.emplace_back(Printpoint(44, 19));
	textboom.emplace_back(Printpoint(54, 17));
	textboom.emplace_back(Printpoint(54, 18));
	textboom.emplace_back(Printpoint(62, 16));
	textboom.emplace_back(Printpoint(62, 17));
	textboom.emplace_back(Printpoint(68, 15));
	textboom.emplace_back(Printpoint(70, 16));
	textboom.emplace_back(Printpoint(74, 15));
	textboom.emplace_back(Printpoint(82, 14));
	textboom.emplace_back(Printpoint(109, 11));
	textboom.emplace_back(Printpoint(111, 11));
	textboom.emplace_back(Printpoint(74, 16));
	textboom.emplace_back(Printpoint(82, 15));
	textboom.emplace_back(Printpoint(87, 14));
	textboom.emplace_back(Printpoint(91, 13));
	textboom.emplace_back(Printpoint(91, 14));
	textboom.emplace_back(Printpoint(96, 12));
	textboom.emplace_back(Printpoint(100, 12));
	textboom.emplace_back(Printpoint(96, 13));
	textboom.emplace_back(Printpoint(100, 13));
	textboom.emplace_back(Printpoint(105, 12));
	textboom.emplace_back(Printpoint(46, 19));

}
void Initialinterface::Text3()
{
	
	textboom2.emplace_back(Printpoint(54, 19));
	textboom2.emplace_back(Printpoint(62, 18));
	textboom2.emplace_back(Printpoint(70, 17));
	textboom2.emplace_back(Printpoint(62, 19));
	textboom2.emplace_back(Printpoint(64, 19));
	textboom2.emplace_back(Printpoint(66, 19));
	textboom2.emplace_back(Printpoint(68, 19));
	textboom2.emplace_back(Printpoint(70, 18));
	textboom2.emplace_back(Printpoint(74, 17));
	textboom2.emplace_back(Printpoint(82, 16));
	textboom2.emplace_back(Printpoint(87, 15));
	textboom2.emplace_back(Printpoint(74, 18));
	textboom2.emplace_back(Printpoint(74, 19));
	textboom2.emplace_back(Printpoint(76, 19));
	textboom2.emplace_back(Printpoint(78, 19));
	textboom2.emplace_back(Printpoint(82, 17));
	textboom2.emplace_back(Printpoint(87, 16));
	textboom2.emplace_back(Printpoint(91, 15));
	textboom2.emplace_back(Printpoint(96, 14));
	textboom2.emplace_back(Printpoint(80, 19));
	textboom2.emplace_back(Printpoint(82, 18));
	textboom2.emplace_back(Printpoint(82, 19));
	textboom2.emplace_back(Printpoint(87, 17));
	textboom2.emplace_back(Printpoint(87, 18));
	textboom2.emplace_back(Printpoint(91, 16));
	textboom2.emplace_back(Printpoint(92, 17));
	textboom2.emplace_back(Printpoint(96, 15));
	textboom2.emplace_back(Printpoint(100, 14));
	textboom2.emplace_back(Printpoint(100, 15));
	textboom2.emplace_back(Printpoint(105, 13));
	textboom2.emplace_back(Printpoint(105, 14));
	textboom2.emplace_back(Printpoint(113, 12));
	textboom2.emplace_back(Printpoint(113, 13));
	textboom2.emplace_back(Printpoint(87, 19));
	textboom2.emplace_back(Printpoint(95, 17));
	textboom2.emplace_back(Printpoint(93, 18));
	textboom2.emplace_back(Printpoint(94, 18));
	textboom2.emplace_back(Printpoint(96, 16));
	textboom2.emplace_back(Printpoint(100, 16));
	textboom2.emplace_back(Printpoint(100, 17));
	textboom2.emplace_back(Printpoint(105, 15));
	textboom2.emplace_back(Printpoint(105, 16));
	textboom2.emplace_back(Printpoint(107, 15));
	textboom2.emplace_back(Printpoint(100, 18));
	textboom2.emplace_back(Printpoint(105, 17));
	textboom2.emplace_back(Printpoint(109, 15));
	textboom2.emplace_back(Printpoint(111, 15));
	textboom2.emplace_back(Printpoint(113, 14));
	textboom2.emplace_back(Printpoint(100, 19));
	textboom2.emplace_back(Printpoint(105, 18));
	textboom2.emplace_back(Printpoint(113, 16));
	textboom2.emplace_back(Printpoint(113, 17));
	textboom2.emplace_back(Printpoint(105, 19));
	textboom2.emplace_back(Printpoint(107, 19));
	textboom2.emplace_back(Printpoint(109, 19));
	textboom2.emplace_back(Printpoint(113, 18));
	textboom2.emplace_back(Printpoint(111, 19));
}
void Initialinterface::PrintText()
{
	PrintText1();
	PrintText2();
	PrintText3();
}
void Initialinterface::Back()
{
	SetColor(DARKRED, DARKRED);
	srand(time(NULL));
	int x = rand() % 115 + 1;
	int y = rand() % 40 + 1;
	back.emplace_back(Printpoint(x, y));

}
void Initialinterface::PrintText1()
{
	SetColor(LIGHTRED,LIGHTRED);
	for (auto& Printpoint : textboom1)
	{

		if (Printpoint.GetX() >= 0)
		{
			Sleep(5);
			Printpoint.Printrectangle();

		}

	}
}
void Initialinterface::PrintText2()
{
	SetColor(LIGHTGREY, LIGHTGREY);
	for (auto& Printpoint : textboom)
	{

		if (Printpoint.GetX() >= 0)
		{
			Sleep(5);
			Printpoint.Printrectangle();

		}

	}
}
void Initialinterface::PrintText3()
{
	SetColor(DARKRED, DARKRED);
	for (auto& Printpoint : textboom2)
	{

		if (Printpoint.GetX() >= 0)
		{
			Sleep(5);
			Printpoint.Printrectangle();

		}

	}
}
void Initialinterface::CleanText()
{
	SetColor(BLACK, BLACK);
	Text3();
	for (auto& Printpoint : textboom2)
	{
		if (Printpoint.GetX() >= 0)
		{
			Printpoint.Clear();
			Sleep(1);
		}
	}
	Text2();
	for (auto& Printpoint : textboom)
	{
		if (Printpoint.GetX() >= 0)
		{
			Printpoint.Clear();
			Sleep(1);
		}
	}
	Text1();
	for (auto& Printpoint : textboom1)
	{
		if (Printpoint.GetX() >= 0)
		{
			Printpoint.Clear();
			Sleep(1);
		}
	}
}
//Loading&Loadingը��
void Initialinterface::Loading()
{
	loading.emplace_back(Printpoint(26,30));
}
void Initialinterface::PrintLoading()
{
	for (auto& Printpoint : loading)
	{
		
	}
		
}
void Initialinterface::Start()
{
	//��ƻ��
	//ǳ��ɫ
	for (int i = 8; i < 24;)
	{
		startlg.emplace_back(Printpoint(i, 0));
		i += 2;
	}
	for (int i = 8; i < 24;)
	{
		startlg.emplace_back(Printpoint(i, 1));
		i += 2;
	}
	for (int i = 8; i < 22;)
	{
		startlg.emplace_back(Printpoint(i, 2));
		i += 2;
	}
	for (int i = 10; i < 20;)
	{
		startlg.emplace_back(Printpoint(i, 3));
		i += 2;
	}
	startlg.emplace_back(Printpoint(12, 4));
	startlg.emplace_back(Printpoint(14, 4));
	for (int i = 14; i < 28;)
	{
		startlg.emplace_back(Printpoint(i, 36));
		i += 2;
	}
	for (int i = 12; i < 30;)
	{
		startlg.emplace_back(Printpoint(i, 37));
		i += 2;
	}
	for (int i = 10; i < 32;)
	{
		startlg.emplace_back(Printpoint(i, 38));
		startlg.emplace_back(Printpoint(i, 39));
		i += 2;
	}
	//����ɫ
	//ƻ��
	for (int i = 24; i < 30;)
	{
		startdg.emplace_back(Printpoint(i, 0));
		startdg.emplace_back(Printpoint(i, 1));
		startdg.emplace_back(Printpoint(i-2, 2));
		i += 2;
	}
	for (int i = 20; i < 28;)
	{
		startdg.emplace_back(Printpoint(i, 3));
		i += 2;
	}
	for (int i = 16; i < 26;)
	{
		startdg.emplace_back(Printpoint(i, 4));
		startdg.emplace_back(Printpoint(i-2, 5));
		i += 2;
	}
	for (int i = 20; i < 26;)
	{
		startdg.emplace_back(Printpoint(i, 34));
		startdg.emplace_back(Printpoint(i + 2, 33));
		startdg.emplace_back(Printpoint(i + 4, 32));
		i += 2;
	}
	//����
	for (int i = 86; i < 96;)
	{
		startdg.emplace_back(Printpoint(i, 31));
		startdg.emplace_back(Printpoint(i, 33));
		i += 2;
	}
	startdg.emplace_back(Printpoint(88, 29));
	startdg.emplace_back(Printpoint(88, 30));
	startdg.emplace_back(Printpoint(92, 30));
	for (int i = 88; i < 96;)
	{
		startdg.emplace_back(Printpoint(i, 32));
		i += 2;
	}
	for (int i = 86; i < 90;)
	{
		startdg.emplace_back(Printpoint(i+2, 34));
		startdg.emplace_back(Printpoint(i, 35));
		i += 2;
	}
	//��ɫ
	//ƻ��
	startdgy.emplace_back(Printpoint(16, 33));
	startdgy.emplace_back(Printpoint(18, 34));
	startdgy.emplace_back(Printpoint(20, 35));
	startdgy.emplace_back(Printpoint(20, 36));
	//ӣ��
	startdgy.emplace_back(Printpoint(0, 17));
	startdgy.emplace_back(Printpoint(2, 18));
	startdgy.emplace_back(Printpoint(2, 19));
	startdgy.emplace_back(Printpoint(2, 20));
	startdgy.emplace_back(Printpoint(4, 20));
	startdgy.emplace_back(Printpoint(99, 17));
    startdgy.emplace_back(Printpoint(99, 18));
	startdgy.emplace_back(Printpoint(101, 16));
	startdgy.emplace_back(Printpoint(103, 15));
	startdgy.emplace_back(Printpoint(105, 14));
	startdgy.emplace_back(Printpoint(107, 13));
	startdgy.emplace_back(Printpoint(109, 12));
	startdgy.emplace_back(Printpoint(111, 13));
	startdgy.emplace_back(Printpoint(113, 14));
	//����
	startdgy.emplace_back(Printpoint(98, 32));
	startdgy.emplace_back(Printpoint(96, 33));
	startdgy.emplace_back(Printpoint(94, 34));
	startdgy.emplace_back(Printpoint(94, 35));
}
void Initialinterface::Start2()
{
	//���ɫ
    //ӣ��
	for (int i = 0; i < 8;)
	{
		startdr.emplace_back(Printpoint(i, 21));
		startdr.emplace_back(Printpoint(i, 28));
		i += 2;
	}
	for (int i = 0; i < 10;)
	{
		startdr.emplace_back(Printpoint(i, 22));
		startdr.emplace_back(Printpoint(i, 27));
		i += 2;
	}
	for (int i = 0; i < 12;)
	{
		startdr.emplace_back(Printpoint(i, 23));
		startdr.emplace_back(Printpoint(i, 24));
		startdr.emplace_back(Printpoint(i, 25));
		startdr.emplace_back(Printpoint(i, 26));
		i += 2;
	}
	for (int i = 18; i < 24;i++)
	{
		startdr.emplace_back(Printpoint(113, i));
		startdr.emplace_back(Printpoint(111, i));
		startdr.emplace_back(Printpoint(101, i));
		startdr.emplace_back(Printpoint(99, i));
		
	}
	for (int i = 19; i < 23; i++)
	{
		startdr.emplace_back(Printpoint(97, i));
		startdr.emplace_back(Printpoint(103, i));
		startdr.emplace_back(Printpoint(109, i));
	}
	for (int i = 20; i < 22; i++)
	{
        startdr.emplace_back(Printpoint(95, i));
		startdr.emplace_back(Printpoint(105, i));
	}
	startdr.emplace_back(Printpoint(113, 17));
	startdr.emplace_back(Printpoint(113, 24));
	
	//����
	//�㽶
	for (int i = 58; i < 62;)
	{
		startly.emplace_back(Printpoint(i, 37));
		startly.emplace_back(Printpoint(i+2, 38));
		startly.emplace_back(Printpoint(i+2, 39));
		i += 2;
	}
	startly.emplace_back(Printpoint(58, 38));
	for (int i = 66; i < 70;)
	{
		startly.emplace_back(Printpoint(i, 0));
		startly.emplace_back(Printpoint(i, 1));
		startly.emplace_back(Printpoint(i, 2));
		i += 2;
	}
	startly.emplace_back(Printpoint(64, 2));
	for (int i = 60; i < 70;)
	{
		startly.emplace_back(Printpoint(i, 3));
		startly.emplace_back(Printpoint(i-2, 4));
		startly.emplace_back(Printpoint(i-6, 5));
		i += 2;
	}
}
void Initialinterface::Start3()
{
	//��ɫ
	//�㽶
	startbl.emplace_back(Printpoint(56, 35));

	//���
    //�㽶
	for (int i = 70; i < 74;)
	{
		startdy.emplace_back(Printpoint(i, 0));
		startdy.emplace_back(Printpoint(i, 1));
		startdy.emplace_back(Printpoint(i, 2));
		startdy.emplace_back(Printpoint(i, 3));
		startdy.emplace_back(Printpoint(i-2, 4));
		startdy.emplace_back(Printpoint(i-4, 5));
		i += 2;
	}
	startdy.emplace_back(Printpoint(64, 5));
	for (int i = 56; i < 68;)
	{
		startdy.emplace_back(Printpoint(i, 6));
		i += 2;
	}
	for (int i = 56; i < 62;)
	{
		startdy.emplace_back(Printpoint(i, 36));
		i += 2;
	}
	startdy.emplace_back(Printpoint(56, 37));
	for (int i = 62; i < 66;)
	{
		startdy.emplace_back(Printpoint(i, 37));
		startdy.emplace_back(Printpoint(i + 2, 38));
		startdy.emplace_back(Printpoint(i + 2, 39));
		i += 2;
	}
	//��ɫ
	//����
	for (int i = 94; i < 98;)
	{
		startp.emplace_back(Printpoint(i, 36));
		startp.emplace_back(Printpoint(i, 37));
		i += 2;
	}
	for (int i = 94; i < 102;)
	{
		startp.emplace_back(Printpoint(i, 38));
		startp.emplace_back(Printpoint(i + 2, 39));
		i += 2;
	}
	startp.emplace_back(Printpoint(92, 38));
	startp.emplace_back(Printpoint(88, 38));
	startp.emplace_back(Printpoint(88, 39));
	for (int i = 96; i < 106;)
	{
		startp.emplace_back(Printpoint(i, 0));
		startp.emplace_back(Printpoint(i, 1));
		startp.emplace_back(Printpoint(i, 2));
		startp.emplace_back(Printpoint(i-2, 3));
		startp.emplace_back(Printpoint(i-2, 4));
		i += 2;
	}
	startp.emplace_back(Printpoint(90, 0));
	startp.emplace_back(Printpoint(106, 0));
	startp.emplace_back(Printpoint(94, 2));
	startp.emplace_back(Printpoint(92, 4));
	for (int i = 96; i < 100;)
	{
		startp.emplace_back(Printpoint(i, 5));
		startp.emplace_back(Printpoint(i, 6));
		startp.emplace_back(Printpoint(i, 7));
		i += 2;
	}
	startp.emplace_back(Printpoint(94, 5));
	startp.emplace_back(Printpoint(100, 5));
	startp.emplace_back(Printpoint(100, 6));
	startp.emplace_back(Printpoint(96, 8));
	//õ����
	//����
    startrr.emplace_back(Printpoint(92, 36));
	for(int i=88;i<94;)
	{
		startrr.emplace_back(Printpoint(i, 37));
		startrr.emplace_back(Printpoint(i+2, 39));
		i += 2;
	}
	startrr.emplace_back(Printpoint(86, 38));
	startrr.emplace_back(Printpoint(86, 39));
	startrr.emplace_back(Printpoint(90, 38));

	for (int i = 0; i < 4;)
	{
		startrr.emplace_back(Printpoint(92, i));
		i += 2;
	}
	startrr.emplace_back(Printpoint(94, 0));
	startrr.emplace_back(Printpoint(94, 1));
	startrr.emplace_back(Printpoint(96, 3));
	startrr.emplace_back(Printpoint(94, 5));

}
void Initialinterface::PrintStart()
{
	for (auto& Printpoint : startlg)
	{
		SetColor(LIGHTGREEN, LIGHTGREEN);
		Printpoint.Printrectangle();
	}
	for (auto& Printpoint : startdg)
	{
		SetColor(DARKGREEN, DARKGREEN);
		Printpoint.Printrectangle();
	}
	for (auto& Printpoint : startdgy)
	{
		SetColor(DARKGREY, DARKGREY);
		Printpoint.Printrectangle();
	}
	for (auto& Printpoint : startdr)
	{
		SetColor(DARKRED, DARKRED);
		Printpoint.Printrectangle();
	}
	for (auto& Printpoint : startly)
	{
		SetColor(LIGHTYELLOW, LIGHTYELLOW);
		Printpoint.Printrectangle();
	}
	for (auto& Printpoint : startbl)
	{
		SetColor(BLACK, BLACK);
		Printpoint.Printrectangle();
	}
	for (auto& Printpoint : startdy)
	{
		SetColor(DARKYELLOW, DARKYELLOW);
		Printpoint.Printrectangle();
	}
	for (auto& Printpoint : startp)
	{
		SetColor(PURPLE, PURPLE);
		Printpoint.Printrectangle();
	}
	for (auto& Printpoint : startrr)
	{
		SetColor(ROSERED, ROSERED);
		Printpoint.Printrectangle();
	}
}
