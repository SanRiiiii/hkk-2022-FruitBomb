#pragma once
#ifndef CONTROLLER_H
#define CONTROLLER_H
class Controller
{
public:
	Controller() {}
	void Start();
	void Color1();
	void Color2();
	void Select();
	void DrawGame();
	bool PlayGame();
	void Game();
	bool GameOver();

};
#endif


